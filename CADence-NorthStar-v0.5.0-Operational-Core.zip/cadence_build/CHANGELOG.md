# Changelog

## 0.5.0 - Operational Core

- Added production queue and route-aware department progression.
- Added dedicated QC queue with pass-to-shipping transition.
- Added shipping records with carrier, tracking number, date, and status.
- Added invoice creation from shipped cases and payment recording.
- Added dashboard metrics for open cases, QC, shipping, invoices, and collections.
- Extended JSON backup and recovery to shipments and invoices.
- Preserved Practice CRM, Doctor CRM, Case Intake, Audit History, and Developer Command Center.

## 0.4.0 - Recovery Build

- Reconstructed the verified repository baseline.
