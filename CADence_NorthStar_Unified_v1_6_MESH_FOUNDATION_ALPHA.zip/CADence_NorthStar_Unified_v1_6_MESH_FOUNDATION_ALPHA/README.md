# CADence NorthStar Unified v1.6 — Mesh Foundation Alpha

This release adds the first real binary geometry ingestion and deterministic mesh-analysis capability to the NorthStar platform.

## Added

- ASCII STL parser
- Binary STL parser
- Unique-vertex and triangle counts
- Bounding-box calculation
- Approximate surface-area calculation
- Connected-component analysis
- Boundary-edge detection
- Non-manifold-edge detection
- Degenerate-triangle detection
- Declared-normal versus geometric-normal agreement
- Watertightness estimate
- Deterministic mesh-quality evidence
- Mesh repository and REST integration
- Semantic scan-node and feature-tree creation after STL analysis

## Run

Requires Node.js 20 or later.

```bash
npm test
npm run validate
npm run validate:copilot
npm run validate:cognitive
npm run validate:runtime
npm run validate:geometry
npm run validate:mesh
npm start
```

Open:

```text
http://127.0.0.1:8090
```

## New endpoints

- `POST /v1/cases/{caseId}/meshes/analyze`
- `GET /v1/cases/{caseId}/meshes`

The analyze endpoint accepts an STL file encoded as `stlBase64`.

## Important boundary

This alpha performs real STL parsing and deterministic topology statistics. It does not yet perform mesh repair, hole filling, smoothing, remeshing, self-intersection detection, signed-distance thickness analysis, margin detection, preparation classification, occlusal simulation, or milling simulation.
