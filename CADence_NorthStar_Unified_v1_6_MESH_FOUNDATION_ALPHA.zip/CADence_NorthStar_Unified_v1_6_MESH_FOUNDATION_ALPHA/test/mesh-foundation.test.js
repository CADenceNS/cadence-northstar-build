import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {
  StlParser,MeshAnalyzer,MeshQualityEngine,MeshRepository
} from "../src/mesh-foundation.js";

const config=JSON.parse(fs.readFileSync(new URL("../config/mesh-foundation.json",import.meta.url),"utf8"));

test("ASCII STL parser loads a closed tetrahedron",()=>{
 const mesh=StlParser.parseFile(new URL("./fixtures/tetra_ascii.stl",import.meta.url));
 assert.equal(mesh.format,"STL_ASCII");
 assert.equal(mesh.triangles.length,4);
 const analysis=MeshAnalyzer.analyze(mesh);
 assert.equal(analysis.vertexCount,4);
 assert.equal(analysis.triangleCount,4);
 assert.equal(analysis.boundaryEdges,0);
 assert.equal(analysis.nonManifoldEdges,0);
 assert.equal(analysis.connectedComponents,1);
 assert.equal(analysis.watertightEstimate,true);
});

test("binary STL parser loads deterministic triangle data",()=>{
 const mesh=StlParser.parseFile(new URL("./fixtures/single_binary.stl",import.meta.url));
 assert.equal(mesh.format,"STL_BINARY");
 assert.equal(mesh.triangles.length,1);
 const analysis=MeshAnalyzer.analyze(mesh);
 assert.equal(analysis.vertexCount,3);
 assert.equal(analysis.boundaryEdges,3);
 assert.equal(analysis.watertightEstimate,false);
});

test("mesh analyzer detects degenerate triangles",()=>{
 const mesh={format:"STL_ASCII",sourceName:"memory",triangles:[
  {normal:[0,0,1],vertices:[[0,0,0],[1,0,0],[2,0,0]]}
 ]};
 const analysis=MeshAnalyzer.analyze(mesh);
 assert.equal(analysis.degenerateTriangles,1);
 assert.equal(analysis.approximateSurfaceArea,0);
});

test("mesh quality engine emits deterministic evidence inputs",()=>{
 const mesh=StlParser.parseFile(new URL("./fixtures/single_binary.stl",import.meta.url));
 const analysis=MeshAnalyzer.analyze(mesh);
 const engine=new MeshQualityEngine(config);
 const evidence=engine.evaluate({caseId:"CASE-M1",subjectId:"SCAN-1",analysis});
 assert.ok(evidence.some(e=>e.findingCode==="MESH.BOUNDARY_EDGES"&&e.status==="REVIEW"));
 assert.ok(evidence.every(e=>e.method==="DETERMINISTIC_STL_TOPOLOGY_ANALYSIS"));
});

test("mesh repository stores analyzed records per case",()=>{
 const repo=new MeshRepository();
 const record=repo.save({
  caseId:"CASE-M2",subjectId:"SCAN-2",fileName:"scan.stl",format:"STL_ASCII",
  analysis:{triangleCount:4},evidenceIds:["EV-1"]
 });
 assert.equal(repo.list("CASE-M2").length,1);
 assert.equal(repo.get(record.meshRecordId).subjectId,"SCAN-2");
});
