import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {NorthStarEventBus} from "../src/event-bus.js";
import {KnowledgeGraph,CognitiveOrchestrator} from "../src/cognitive-platform.js";

const guided=JSON.parse(fs.readFileSync(new URL("../config/guided-workflows.json",import.meta.url),"utf8"));

test("digital twin records and updates case lifecycle",()=>{
 const bus=new NorthStarEventBus({allowedEvents:guided.eventTypes,allowedModules:guided.modules});
 const graph=new KnowledgeGraph();
 const cognitive=new CognitiveOrchestrator({bus,graph});
 cognitive.registerCase({caseId:"TWIN-1",modality:"FIXED",doctorId:"DOC-1",patientId:"PAT-1"});
 bus.publish({eventType:"CASE_CREATED",sourceModule:"CASES",caseId:"TWIN-1",payload:{modality:"FIXED"}});
 bus.publish({eventType:"SCAN_VALIDATED",sourceModule:"DIGITAL_INTAKE",caseId:"TWIN-1",payload:{}});
 bus.publish({eventType:"HUMAN_QC_APPROVED",sourceModule:"QUALITY_CONTROL",caseId:"TWIN-1",payload:{}});
 const twin=cognitive.getTwin("TWIN-1");
 assert.equal(twin.state.workflow.currentStepId,"PRODUCTION");
 assert.ok(twin.timeline.length>=3);
 assert.ok(twin.version>=4);
});

test("knowledge graph links case, doctor, patient, and events",()=>{
 const bus=new NorthStarEventBus({allowedEvents:guided.eventTypes,allowedModules:guided.modules});
 const graph=new KnowledgeGraph();
 const cognitive=new CognitiveOrchestrator({bus,graph});
 cognitive.registerCase({caseId:"GRAPH-1",modality:"IMPLANT",doctorId:"DOC-2",patientId:"PAT-2"});
 bus.publish({eventType:"CASE_CREATED",sourceModule:"CASES",caseId:"GRAPH-1",payload:{modality:"IMPLANT"}});
 const neighborhood=graph.neighborhood("CASE:GRAPH-1");
 assert.ok(neighborhood.linkedNodes.some(n=>n.nodeType==="DOCTOR"));
 assert.ok(neighborhood.linkedNodes.some(n=>n.nodeType==="PATIENT"));
 assert.ok(neighborhood.linkedNodes.some(n=>n.nodeType==="EVENT"));
});

test("failed design checkpoint creates explainable recommendation",()=>{
 const bus=new NorthStarEventBus({allowedEvents:guided.eventTypes,allowedModules:guided.modules});
 const graph=new KnowledgeGraph();
 const cognitive=new CognitiveOrchestrator({bus,graph});
 cognitive.registerCase({caseId:"REC-1",modality:"FIXED"});
 bus.publish({
  eventType:"DESIGN_CHECKPOINT_FAILED",sourceModule:"CAD_STUDIO",caseId:"REC-1",
  payload:{summary:"Margin gap exceeded tolerance.",severity:"HIGH",recommendedAction:"Refine the distal margin and rerun validation.",successCriteria:"Closed-loop gap is 0.02 mm or less."}
 });
 const recs=cognitive.getRecommendations("REC-1");
 assert.equal(recs.length,1);
 assert.equal(recs[0].engineId,"CAD_INTELLIGENCE");
 assert.equal(recs[0].severity,"HIGH");
 assert.ok(recs[0].evidence.length>0);
 assert.equal(recs[0].humanReview.required,true);
});

test("final QC failure creates training recommendation",()=>{
 const bus=new NorthStarEventBus({allowedEvents:guided.eventTypes,allowedModules:guided.modules});
 const graph=new KnowledgeGraph();
 const cognitive=new CognitiveOrchestrator({bus,graph});
 cognitive.registerCase({caseId:"TRAIN-1",modality:"REMOVABLE"});
 bus.publish({eventType:"FINAL_QC_FAILED",sourceModule:"QUALITY_CONTROL",caseId:"TRAIN-1",payload:{category:"OCCLUSION"}});
 const recs=cognitive.getRecommendations("TRAIN-1");
 assert.ok(recs.some(r=>r.engineId==="KNOWLEDGE_INTELLIGENCE"));
});
