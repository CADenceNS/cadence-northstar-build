import test from "node:test";
import assert from "node:assert/strict";
import {determinePlan} from "../src/daas/rules.js";
import {evaluateQuality} from "../src/daas/quality.js";
import {analyzeCase} from "../src/copilot.js";

const file={path:"s3://case/design.stl",format:"STL",sha256:"a".repeat(64)};

test("fixed copilot explains margin and thickness failures",()=>{
 const input={caseId:"COP-FIXED",modality:"FIXED",variant:"VENEER",files:[file],metrics:{marginClosedLoopGapMm:0.03,wallThicknessSamplesMm:[0.3,0.5]}};
 const plan=determinePlan(input),quality=evaluateQuality(input,plan);
 const result=analyzeCase(input,plan,quality,{currentStepId:"STRUCTURAL_QC",responsibleModule:"DAAS",completionPercent:55});
 assert.equal(result.summary.result,"CORRECTION_REQUIRED");
 assert.equal(result.summary.blockedFromManufacturing,true);
 assert.equal(result.nextBestAction.severity,"HIGH");
 assert.ok(result.findings.every(f=>f.purpose&&f.whyItMatters&&f.recommendedAction&&f.successCriteria));
});

test("implant copilot prioritizes critical nerve safety",()=>{
 const input={caseId:"COP-IMP",modality:"IMPLANT",variant:"SURGICAL_GUIDE",files:[file],metrics:{minimumFixtureToRootMm:1,minimumFixtureToNerveMm:1.5,sleeveGapOffsetMm:0.1}};
 const plan=determinePlan(input),quality=evaluateQuality(input,plan);
 const result=analyzeCase(input,plan,quality);
 assert.equal(result.nextBestAction.findingId,"IMPLANT_NERVE_SAFETY_REVIEW");
 assert.equal(result.nextBestAction.severity,"CRITICAL");
});

test("passing case directs user to human QC",()=>{
 const input={caseId:"COP-PASS",modality:"FIXED",variant:"VENEER",files:[file],metrics:{marginClosedLoopGapMm:0.01,wallThicknessSamplesMm:[0.4,0.5]}};
 const plan=determinePlan(input),quality=evaluateQuality(input,plan);
 const result=analyzeCase(input,plan,quality,{currentStepId:"HUMAN_QC",responsibleModule:"QUALITY_CONTROL",completionPercent:70,instruction:"Review and approve.","successCriteria":"A named reviewer approves the case."});
 assert.equal(result.summary.result,"READY_FOR_HUMAN_QC");
 assert.equal(result.nextBestAction.severity,"INFO");
 assert.equal(result.workflowContext.responsibleModule,"QUALITY_CONTROL");
});
