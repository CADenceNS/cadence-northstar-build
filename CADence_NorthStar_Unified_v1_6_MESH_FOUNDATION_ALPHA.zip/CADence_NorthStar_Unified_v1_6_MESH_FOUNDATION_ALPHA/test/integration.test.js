import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {NorthStarEventBus} from "../src/event-bus.js";
import {GuidedCompletionEngine} from "../src/guided-engine.js";
import {wireNorthStarModules} from "../src/integration.js";

const config=JSON.parse(fs.readFileSync(new URL("../config/guided-workflows.json",import.meta.url),"utf8"));

test("all modalities expose complete next-step guidance",()=>{
  const engine=new GuidedCompletionEngine();
  for(const modality of Object.keys(config.workflows)){
    const guidance=engine.createCase({caseId:`CASE-${modality}`,modality,createdBy:"TEST"});
    assert.equal(guidance.currentStepId,"CASE_INTAKE");
    assert.ok(guidance.instruction.length>40);
    assert.ok(guidance.successCriteria.length>30);
    assert.ok(guidance.responsibleModule);
  }
});

test("workflow cannot advance without complete evidence",()=>{
  const engine=new GuidedCompletionEngine();
  engine.createCase({caseId:"CASE-EVIDENCE",modality:"FIXED"});
  assert.throws(()=>engine.completeStep({
    caseId:"CASE-EVIDENCE",stepId:"CASE_INTAKE",
    evidence:{USER_ACKNOWLEDGEMENT:true,SYSTEM_VALIDATION:true},
    completedBy:"TECH-1"
  }),/AUDIT_EVENT/);
});

test("completed step advances to the exact configured next step",()=>{
  const engine=new GuidedCompletionEngine();
  engine.createCase({caseId:"CASE-FLOW",modality:"FIXED"});
  const guidance=engine.completeStep({
    caseId:"CASE-FLOW",stepId:"CASE_INTAKE",
    evidence:{USER_ACKNOWLEDGEMENT:true,SYSTEM_VALIDATION:true,AUDIT_EVENT:"AUDIT-0001"},
    completedBy:"TECH-1"
  });
  assert.equal(guidance.currentStepId,"SCAN_VALIDATION");
  assert.equal(guidance.responsibleModule,"DIGITAL_INTAKE");
});

test("events communicate to downstream modules and guidance layer",()=>{
  const bus=new NorthStarEventBus({allowedEvents:config.eventTypes,allowedModules:config.modules});
  const engine=new GuidedCompletionEngine();
  engine.createCase({caseId:"CASE-BUS",modality:"IMPLANT"});
  const integration=wireNorthStarModules(bus,engine);
  bus.publish({eventType:"FINAL_QC_PASSED",sourceModule:"QUALITY_CONTROL",caseId:"CASE-BUS",payload:{approved:true},actorId:"QC-1"});
  const deliveries=integration.getDeliveries("CASE-BUS");
  assert.ok(deliveries.some(d=>d.deliveredTo.includes("SHIPPING")));
  assert.ok(deliveries.some(d=>d.deliveredTo.includes("BILLING")));
  assert.ok(deliveries.some(d=>d.deliveredTo.includes("AUDIT")));
});

test("invalid event and module names are rejected",()=>{
  const bus=new NorthStarEventBus({allowedEvents:config.eventTypes,allowedModules:config.modules});
  assert.throws(()=>bus.publish({eventType:"UNKNOWN",sourceModule:"CASES",caseId:"CASE-1"}),/Unsupported eventType/);
  assert.throws(()=>bus.publish({eventType:"CASE_CREATED",sourceModule:"UNKNOWN",caseId:"CASE-1"}),/Unsupported sourceModule/);
});
