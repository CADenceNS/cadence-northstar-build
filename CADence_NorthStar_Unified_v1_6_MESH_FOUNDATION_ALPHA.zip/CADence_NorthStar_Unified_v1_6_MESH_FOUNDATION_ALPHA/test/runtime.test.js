import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {
  GovernanceLedger,ResourceManager,CaseStateMachine,RevisionRepository,
  ClinicalRuleLibrary,ManufacturingProfileRegistry,JobEngine,CommandRuntime
} from "../src/runtime.js";

const runtimeConfig=JSON.parse(fs.readFileSync(new URL("../config/runtime.json",import.meta.url),"utf8"));
const rulesConfig=JSON.parse(fs.readFileSync(new URL("../config/clinical-rules.json",import.meta.url),"utf8"));
const profilesConfig=JSON.parse(fs.readFileSync(new URL("../config/manufacturing-profiles.json",import.meta.url),"utf8"));

function fixture(){
 const governance=new GovernanceLedger();
 const resources=new ResourceManager({CPU:2,GPU:0,MEMORY_GB:8,STORAGE_GB:20,WORKER:2});
 const stateMachine=new CaseStateMachine({states:runtimeConfig.caseStates,transitions:runtimeConfig.stateTransitions});
 const revisions=new RevisionRepository();
 const rules=new ClinicalRuleLibrary(rulesConfig);
 const profiles=new ManufacturingProfileRegistry(profilesConfig);
 const jobs=new JobEngine({resourceManager:resources});
 const runtime=new CommandRuntime({
  allowedCommands:runtimeConfig.commandTypes,stateMachine,revisions,jobs,rules,profiles,governance
 });
 return {governance,resources,stateMachine,revisions,rules,profiles,jobs,runtime};
}

const base={actorId:"USR-1",actorRole:"ADMIN",reason:"Automated runtime test",source:"TEST",correlationId:"CORR-1"};

test("command runtime creates canonical case state and initial revision",()=>{
 const {runtime,stateMachine,revisions,governance}=fixture();
 const command=runtime.execute({...base,commandType:"CREATE_CASE",caseId:"CASE-R1",payload:{},idempotencyKey:"create-case-r1"});
 assert.equal(command.status,"SUCCEEDED");
 assert.equal(stateMachine.get("CASE-R1").state,"RECEIVED");
 assert.equal(revisions.get("CASE-R1").branches[0].branchName,"main");
 assert.equal(governance.list("CASE-R1").length,1);
});

test("case state machine rejects invalid transitions",()=>{
 const {runtime}=fixture();
 runtime.execute({...base,commandType:"CREATE_CASE",caseId:"CASE-R2"});
 assert.throws(()=>runtime.execute({...base,commandType:"TRANSITION_CASE",caseId:"CASE-R2",payload:{toState:"PRODUCTION"},correlationId:"CORR-2"}),/Invalid transition/);
});

test("revision repository supports branch, checkout, and merge",()=>{
 const {runtime,revisions}=fixture();
 runtime.execute({...base,commandType:"CREATE_CASE",caseId:"CASE-R3"});
 runtime.execute({...base,commandType:"CREATE_REVISION",caseId:"CASE-R3",payload:{label:"Margin refinement"},correlationId:"CORR-3"});
 runtime.execute({...base,commandType:"CREATE_BRANCH",caseId:"CASE-R3",payload:{branchName:"alternate-anatomy"},correlationId:"CORR-4"});
 runtime.execute({...base,commandType:"CHECKOUT_REVISION",caseId:"CASE-R3",payload:{branchName:"alternate-anatomy"},correlationId:"CORR-5"});
 runtime.execute({...base,commandType:"CREATE_REVISION",caseId:"CASE-R3",payload:{label:"Alternate morphology"},correlationId:"CORR-6"});
 runtime.execute({...base,commandType:"MERGE_BRANCH",caseId:"CASE-R3",payload:{sourceBranch:"alternate-anatomy",targetBranch:"main"},correlationId:"CORR-7"});
 const repo=revisions.get("CASE-R3");
 assert.equal(repo.branches.length,2);
 assert.ok(repo.revisions.some(r=>r.parentRevisionIds.length===2));
});

test("clinical rule library produces deterministic pass and fail evidence",()=>{
 const {rules}=fixture();
 const failed=rules.evaluate("FIXED_ZIRCONIA_DEFAULT",{
  MIN_WALL_THICKNESS:0.6,MIN_OCCLUSAL_THICKNESS:1.2,MARGIN_LOOP_CLOSED:true,MAX_CONTACT_PENETRATION:0.02
 });
 assert.equal(failed.passed,false);
 assert.equal(failed.results.find(r=>r.ruleId==="MIN_WALL_THICKNESS").passed,false);
 const passed=rules.evaluate("FIXED_ZIRCONIA_DEFAULT",{
  MIN_WALL_THICKNESS:0.9,MIN_OCCLUSAL_THICKNESS:1.2,MARGIN_LOOP_CLOSED:true,MAX_CONTACT_PENETRATION:0.02
 });
 assert.equal(passed.passed,true);
});

test("dependency-aware job engine blocks, runs, releases resources, and unblocks",()=>{
 const {jobs,resources}=fixture();
 const first=jobs.create({caseId:"CASE-R4",jobType:"SCAN_REPAIR",resources:{CPU:1,MEMORY_GB:2,WORKER:1}});
 const second=jobs.create({caseId:"CASE-R4",jobType:"MORPHOLOGY",dependencies:[first.jobId],resources:{CPU:1,MEMORY_GB:2,WORKER:1}});
 assert.equal(jobs.get(second.jobId).status,"BLOCKED");
 jobs.start(first.jobId);
 assert.equal(resources.used().CPU,1);
 jobs.updateProgress(first.jobId,45);
 jobs.complete(first.jobId,{meshStatus:"REPAIRED"});
 assert.equal(resources.used().CPU,0);
 assert.equal(jobs.get(second.jobId).status,"QUEUED");
});

test("manufacturing profile registry selects compatible process and material",()=>{
 const {profiles}=fixture();
 const profile=profiles.select({process:"MILLING",material:"ZIRCONIA"});
 assert.equal(profile.profileId,"MILL_ZIRCONIA_5AXIS_DEFAULT");
});
