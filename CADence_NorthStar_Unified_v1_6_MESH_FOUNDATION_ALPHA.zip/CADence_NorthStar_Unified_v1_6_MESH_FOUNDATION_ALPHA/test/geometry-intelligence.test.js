import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {
 EngineeringEvidenceFactory,SemanticGeometryGraph,FeatureTree,ConstraintPropagationEngine,
 DesignVariantRepository,ManufacturingTwin,GeometryIntelligenceService
} from "../src/geometry-intelligence.js";

const geometryConfig=JSON.parse(fs.readFileSync(new URL("../config/geometry-intelligence.json",import.meta.url),"utf8"));
const constraintConfig=JSON.parse(fs.readFileSync(new URL("../config/constraint-network.json",import.meta.url),"utf8"));

function fixture(){
 const graph=new SemanticGeometryGraph({allowedTypes:geometryConfig.semanticTypes});
 const features=new FeatureTree();
 const constraints=new ConstraintPropagationEngine(constraintConfig);
 const variants=new DesignVariantRepository();
 const manufacturingTwin=new ManufacturingTwin();
 const service=new GeometryIntelligenceService({graph,features,constraints,variants,manufacturingTwin});
 service.initializeCase("CASE-G1");
 return {graph,features,constraints,variants,manufacturingTwin,service};
}

test("semantic geometry graph models dental objects and relationships",()=>{
 const {graph}=fixture();
 const tooth=graph.addNode({caseId:"CASE-G1",type:"TOOTH",label:"Tooth 30"});
 const prep=graph.addNode({caseId:"CASE-G1",type:"PREPARATION",label:"Preparation 30"});
 const margin=graph.addNode({caseId:"CASE-G1",type:"MARGIN",label:"Margin 30"});
 graph.connect({fromNodeId:tooth.nodeId,toNodeId:prep.nodeId,relationship:"HAS_PREPARATION"});
 graph.connect({fromNodeId:prep.nodeId,toNodeId:margin.nodeId,relationship:"HAS_MARGIN"});
 const neighborhood=graph.neighborhood(prep.nodeId);
 assert.equal(neighborhood.neighbors.length,2);
 assert.equal(graph.caseGraph("CASE-G1").edges.length,2);
});

test("feature tree records ordered and replayable design intent",()=>{
 const {features}=fixture();
 const first=features.add({caseId:"CASE-G1",featureType:"IMPORT_SCAN",label:"Import upper scan",createdBy:"USR-1"});
 const second=features.add({caseId:"CASE-G1",featureType:"DETECT_MARGIN",label:"Detect finish line",parameters:{method:"RULE_BASED"},createdBy:"USR-1"});
 assert.equal(second.parentFeatureId,first.featureId);
 features.suppress("CASE-G1",second.featureId);
 assert.equal(features.get("CASE-G1").features[1].status,"SUPPRESSED");
});

test("engineering evidence enforces standardized explainable output",()=>{
 const evidence=EngineeringEvidenceFactory.create({
  engineId:"THICKNESS_ENGINE",caseId:"CASE-G1",subjectId:"REST-1",
  findingCode:"MIN_WALL_THICKNESS",title:"Minimum wall thickness review",
  status:"FAIL",severity:"HIGH",confidence:0.98,summary:"Measured wall thickness is below the configured material requirement.",
  measuredValue:0.6,requiredValue:0.8,unit:"mm",
  recommendedAction:"Increase restoration thickness in the identified region.",
  successCriteria:"The measured wall thickness meets or exceeds 0.8 mm."
 });
 assert.equal(evidence.schemaVersion,"2.0.0");
 assert.equal(evidence.status,"FAIL");
 assert.equal(evidence.humanReviewRequired,true);
});

test("constraint propagation invalidates only affected engineering checks",()=>{
 const {constraints}=fixture();
 constraints.recordEvaluation("CASE-G1","FIXED.MIN_WALL_THICKNESS",{status:"PASS",evidenceId:"EV-1"});
 const invalidated=constraints.invalidateByDependency("CASE-G1","MATERIAL.PROFILE");
 assert.ok(invalidated.includes("FIXED.MIN_WALL_THICKNESS"));
 const state=constraints.snapshot("CASE-G1").find(s=>s.constraintId==="FIXED.MIN_WALL_THICKNESS");
 assert.equal(state.stale,true);
 assert.equal(state.status,"NOT_EVALUATED");
});

test("design variants support structured comparison",()=>{
 const {variants,features}=fixture();
 features.add({caseId:"CASE-G1",featureType:"GENERATE_MORPHOLOGY",label:"Natural anatomy"});
 const a=variants.create({caseId:"CASE-G1",name:"Natural Anatomy",branchName:"natural",featureSnapshot:features.get("CASE-G1"),evidenceIds:["EV-A"]});
 features.add({caseId:"CASE-G1",featureType:"ADJUST_OCCLUSION",label:"Reduced anatomy"});
 const b=variants.create({caseId:"CASE-G1",name:"Reduced Anatomy",branchName:"reduced",featureSnapshot:features.get("CASE-G1"),evidenceIds:["EV-B"]});
 const comparison=variants.compare("CASE-G1",a.variantId,b.variantId);
 assert.equal(comparison.differences.branchChanged,true);
 assert.equal(comparison.differences.featureSnapshotChanged,true);
});

test("manufacturing twin records stages, material lots, machine runs, and evidence",()=>{
 const {manufacturingTwin}=fixture();
 manufacturingTwin.recordStage({caseId:"CASE-G1",stage:"MILLING",status:"COMPLETED",actorId:"USR-2",evidenceIds:["EV-1"]});
 manufacturingTwin.attachMaterialLot("CASE-G1",{lotId:"ZIR-LOT-10",material:"ZIRCONIA"});
 manufacturingTwin.attachMachineRun("CASE-G1",{runId:"RUN-10",machineId:"MILL-1"});
 manufacturingTwin.attachQualityEvidence("CASE-G1","EV-2");
 const twin=manufacturingTwin.get("CASE-G1");
 assert.equal(twin.currentStage,"MILLING");
 assert.equal(twin.materialLots.length,1);
 assert.equal(twin.machineRuns.length,1);
 assert.equal(twin.qualityEvidenceIds.length,1);
});

test("geometry intelligence service returns one unified case snapshot",()=>{
 const {service,graph,features}=fixture();
 graph.addNode({caseId:"CASE-G1",type:"RESTORATION",label:"Crown 30"});
 features.add({caseId:"CASE-G1",featureType:"APPLY_MATERIAL_PROFILE",label:"Apply zirconia profile"});
 service.addEvidence({
  engineId:"MANUFACTURING_ENGINE",caseId:"CASE-G1",subjectId:"REST-1",
  findingCode:"MILLABILITY",title:"Milling accessibility review",status:"PASS",severity:"INFO",
  confidence:0.95,summary:"Declared manufacturing inputs satisfy the configured accessibility rule.",
  recommendedAction:"Proceed to qualified human manufacturing review."
 });
 const snapshot=service.snapshot("CASE-G1");
 assert.equal(snapshot.semanticGraph.nodes.length,1);
 assert.equal(snapshot.featureTree.features.length,1);
 assert.equal(snapshot.evidence.length,1);
 assert.ok(snapshot.manufacturingTwin);
});
