import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import {DurableJsonStore} from "../src/store.js";
import {GuidedCompletionEngine} from "../src/guided-engine.js";
import {determinePlan} from "../src/daas/rules.js";
import {evaluateQuality} from "../src/daas/quality.js";
import {buildManifest} from "../src/daas/manifest.js";

test("workflow state persists across engine restart",()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),"cadence-"));
 const file=path.join(dir,"state.json");
 const store1=new DurableJsonStore(file);
 const engine1=new GuidedCompletionEngine({store:store1});
 engine1.createCase({caseId:"PERSIST-1",modality:"FIXED"});
 engine1.completeStep({caseId:"PERSIST-1",stepId:"CASE_INTAKE",completedBy:"TECH",evidence:{USER_ACKNOWLEDGEMENT:true,SYSTEM_VALIDATION:true,AUDIT_EVENT:"AUDIT-1234"}});
 const store2=new DurableJsonStore(file);
 const engine2=new GuidedCompletionEngine({store:store2});
 assert.equal(engine2.getGuidance("PERSIST-1").currentStepId,"SCAN_VALIDATION");
});

test("DaaS output and guidance can coexist for the same case",()=>{
 const input={caseId:"UNIFIED-1",modality:"FIXED",variant:"VENEER",files:[
  {path:"s3://case/design.stl",format:"STL",sha256:"a".repeat(64)},
  {path:"s3://case/view.png",format:"PNG",sha256:"b".repeat(64)}
 ],metrics:{marginClosedLoopGapMm:0.01,wallThicknessSamplesMm:[0.4,0.5]}};
 const plan=determinePlan(input);
 const quality=evaluateQuality(input,plan);
 const manifest=buildManifest(input,plan,quality);
 assert.equal(quality.passed,true);
 assert.equal(manifest.manufacturing.releaseState,"AWAITING_HUMAN_QC");
});
