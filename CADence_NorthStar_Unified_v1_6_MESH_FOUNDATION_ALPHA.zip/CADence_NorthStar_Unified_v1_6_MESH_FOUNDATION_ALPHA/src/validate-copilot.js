import fs from "node:fs";
const config=JSON.parse(fs.readFileSync(new URL("../config/copilot-rules.json",import.meta.url),"utf8"));
const modalities=["FIXED","IMPLANT","REMOVABLE","ORTHO","SLEEP","DIAGNOSTICS"];
const ids=new Set();
for(const modality of modalities){
  const section=config.modalities[modality];
  if(!section) throw new Error(`Missing modality ${modality}`);
  if(!Array.isArray(section.requiredMetrics)||section.requiredMetrics.length===0) throw new Error(`${modality} requires metrics.`);
  if(!Array.isArray(section.rules)||section.rules.length<2) throw new Error(`${modality} requires at least two rules.`);
  for(const rule of section.rules){
    if(ids.has(rule.id)) throw new Error(`Duplicate rule ID ${rule.id}`);
    ids.add(rule.id);
    for(const field of ["title","purpose","whyItMatters","actionOnFail","successCriteria"]){
      if(typeof rule[field]!=="string"||rule[field].length<30) throw new Error(`${rule.id}.${field} is incomplete.`);
    }
    if(!config.severityOrder.includes(rule.severityOnFail)) throw new Error(`${rule.id} has invalid severity.`);
  }
}
console.log("Clinical Design Copilot validation PASS");
