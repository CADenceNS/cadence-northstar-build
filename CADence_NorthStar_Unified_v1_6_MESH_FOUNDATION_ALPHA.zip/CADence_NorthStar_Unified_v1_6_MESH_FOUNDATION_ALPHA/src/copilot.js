import fs from "node:fs";

const config=JSON.parse(fs.readFileSync(new URL("../config/copilot-rules.json",import.meta.url),"utf8"));

const number=(value,name)=>{
  if(typeof value!=="number"||!Number.isFinite(value)) throw new Error(`${name} must be a finite number.`);
  return value;
};

function severityRank(severity){return config.severityOrder.indexOf(severity);}
function confidenceBand(score){
  if(score>=0.80) return "HIGH";
  if(score>=0.60) return "MEDIUM";
  return "LOW";
}
function metricCompleteness(input,required){
  const present=required.filter(key=>key in input.metrics && input.metrics[key]!==null && input.metrics[key]!==undefined).length;
  return required.length===0?1:present/required.length;
}
function confidenceFor(input,rule){
  const completeness=metricCompleteness(input,config.modalities[input.modality].requiredMetrics);
  const provenance=Array.isArray(input.files)&&input.files.every(file=>typeof file.sha256==="string"&&file.sha256.length===64)?1:0.7;
  const directness=["LTE","GTE","GT","IN","DELTA_LTE_METRIC","ABS_BOTH_LTE","ARRAY_MIN_GTE_PLAN"].includes(rule.operator)?1:0.9;
  const score=Math.max(0,Math.min(1,0.5*completeness+0.3*provenance+0.2*directness));
  return {score:Number(score.toFixed(2)),band:confidenceBand(score)};
}
function maxStage(input,key){
  let max=0;
  for(const stage of input.metrics.stages){
    for(const tooth of stage.teeth){
      max=Math.max(max,Math.abs(number(tooth[key],key)));
    }
  }
  return max;
}
function evaluateRule(input,plan,rule){
  const m=input.metrics;
  let actual,required,passed;
  switch(rule.operator){
    case "LTE":
      actual=number(m[rule.metric],rule.metric);required=`<= ${rule.threshold}`;passed=actual<=rule.threshold;break;
    case "GTE":
      actual=number(m[rule.metric],rule.metric);required=`>= ${rule.threshold}`;passed=actual>=rule.threshold;break;
    case "GT":
      actual=number(m[rule.metric],rule.metric);required=`> ${rule.threshold}`;passed=actual>rule.threshold;break;
    case "IN":
      actual=number(m[rule.metric],rule.metric);required=rule.allowed;passed=rule.allowed.includes(actual);break;
    case "ARRAY_MIN_GTE_PLAN":{
      if(!Array.isArray(m[rule.metric])||m[rule.metric].length===0) throw new Error(`${rule.metric} must be non-empty.`);
      actual=Math.min(...m[rule.metric].map((v,i)=>number(v,`${rule.metric}[${i}]`)));
      const threshold=number(plan[rule.planField],rule.planField);required=`>= ${threshold}`;passed=actual>=threshold;break;
    }
    case "DELTA_LTE_METRIC":{
      const value=number(m[rule.metric],rule.metric),reference=number(m[rule.referenceMetric],rule.referenceMetric);
      actual=Number(Math.abs(value-reference).toFixed(3));required=`<= ${rule.threshold} difference`;passed=actual<=rule.threshold;break;
    }
    case "MAX_STAGE_ROTATION_LTE":
      actual=maxStage(input,"rotationDeg");required=`<= ${rule.threshold} degrees`;passed=actual<=rule.threshold;break;
    case "MAX_STAGE_TRANSLATION_LTE":
      actual=maxStage(input,"translationMm");required=`<= ${rule.threshold} mm`;passed=actual<=rule.threshold;break;
    case "ABS_BOTH_LTE":{
      const left=Math.abs(number(m[rule.metric],rule.metric)),right=Math.abs(number(m[rule.otherMetric],rule.otherMetric));
      actual={left,right};required=`both <= ${rule.threshold}`;passed=left<=rule.threshold&&right<=rule.threshold;break;
    }
    case "WITHIN_ENVELOPE":{
      actual={minX:m.designMinXMm,maxX:m.designMaxXMm,minZ:m.designMinZMm,maxZ:m.designMaxZMm};
      required={minX:m.biologicalEnvelopeMinXMm,maxX:m.biologicalEnvelopeMaxXMm,minZ:m.biologicalEnvelopeMinZMm,maxZ:m.biologicalEnvelopeMaxZMm};
      passed=actual.minX>=required.minX&&actual.maxX<=required.maxX&&actual.minZ>=required.minZ&&actual.maxZ<=required.maxZ;break;
    }
    case "MIDLINE_POLICY":{
      const crosses=m.designMinXMm<m.facialMidlineXMm&&m.designMaxXMm>m.facialMidlineXMm;
      actual={crosses,prohibited:Boolean(m.midlineCrossingProhibited)};
      required="must not cross when prohibited";
      passed=!Boolean(m.midlineCrossingProhibited)||!crosses;break;
    }
    default: throw new Error(`Unsupported copilot operator: ${rule.operator}`);
  }
  const confidence=confidenceFor(input,rule);
  return {
    findingId:rule.id,
    title:rule.title,
    status:passed?"PASS":"ACTION_REQUIRED",
    severity:passed?"INFO":rule.severityOnFail,
    confidence,
    actual,
    required,
    purpose:rule.purpose,
    whyItMatters:rule.whyItMatters,
    recommendedAction:passed?"No corrective action is required. Continue to the next configured workflow step.":rule.actionOnFail,
    successCriteria:rule.successCriteria
  };
}

export function analyzeCase(input,plan,quality,guidance=null){
  const modalityConfig=config.modalities[input.modality];
  if(!modalityConfig) throw new Error(`No copilot configuration for ${input.modality}`);
  const findings=modalityConfig.rules.map(rule=>evaluateRule(input,plan,rule));
  const actionable=findings.filter(f=>f.status==="ACTION_REQUIRED")
    .sort((a,b)=>severityRank(b.severity)-severityRank(a.severity)||b.confidence.score-a.confidence.score);
  const top=actionable[0]??null;
  const overallConfidence=Number((findings.reduce((sum,f)=>sum+f.confidence.score,0)/findings.length).toFixed(2));
  const blocked=actionable.some(f=>["CRITICAL","HIGH"].includes(f.severity));
  return {
    schemaVersion:"1.0.0",
    caseId:input.caseId,
    modality:input.modality,
    variant:input.variant,
    generatedAt:new Date().toISOString(),
    summary:{
      result:actionable.length===0?"READY_FOR_HUMAN_QC":"CORRECTION_REQUIRED",
      blockedFromManufacturing:blocked,
      passedFindings:findings.length-actionable.length,
      actionRequiredFindings:actionable.length,
      overallConfidence:{score:overallConfidence,band:confidenceBand(overallConfidence)}
    },
    nextBestAction:top?{
      findingId:top.findingId,
      severity:top.severity,
      instruction:top.recommendedAction,
      why:top.whyItMatters,
      successCriteria:top.successCriteria
    }:{
      findingId:null,
      severity:"INFO",
      instruction:guidance?.instruction??"Send the design and validation record to the required human QC review.",
      why:"All configured automated checks passed; human release approval remains required.",
      successCriteria:guidance?.successCriteria??"A named QC technician reviews and electronically approves the case."
    },
    workflowContext:guidance?{
      currentStepId:guidance.currentStepId,
      responsibleModule:guidance.responsibleModule,
      completionPercent:guidance.completionPercent
    }:null,
    findings,
    qualityDisposition:quality.disposition
  };
}
