import crypto from "node:crypto";
const clone=v=>structuredClone(v);
const now=()=>new Date().toISOString();

export class EngineeringEvidenceFactory{
  static create(input){
    const required=["engineId","caseId","subjectId","findingCode","title","status","severity","confidence","summary","recommendedAction"];
    for(const field of required){
      if(input[field]===undefined||input[field]===null||input[field]==="") throw new Error(`Evidence field ${field} is required.`);
    }
    if(typeof input.confidence!=="number"||input.confidence<0||input.confidence>1) throw new Error("Evidence confidence must be between 0 and 1.");
    return {
      evidenceId:crypto.randomUUID(),
      schemaVersion:"2.0.0",
      engineId:input.engineId,
      caseId:input.caseId,
      subjectId:input.subjectId,
      findingCode:input.findingCode,
      title:input.title,
      status:input.status,
      severity:input.severity,
      confidence:input.confidence,
      summary:input.summary,
      measuredValue:input.measuredValue??null,
      requiredValue:input.requiredValue??null,
      unit:input.unit??null,
      method:input.method??"DECLARED_INPUT",
      assumptions:clone(input.assumptions??[]),
      sourceGeometryRevisionIds:clone(input.sourceGeometryRevisionIds??[]),
      supportingSubjectIds:clone(input.supportingSubjectIds??[]),
      recommendedAction:input.recommendedAction,
      successCriteria:input.successCriteria??"A qualified reviewer confirms the configured requirement is satisfied.",
      humanReviewRequired:input.humanReviewRequired??true,
      createdAt:now()
    };
  }
}

export class SemanticGeometryGraph{
  constructor({allowedTypes=[]}={}){
    this.allowedTypes=new Set(allowedTypes);
    this.nodes=new Map();
    this.edges=new Map();
  }
  addNode({caseId,type,label,metadata={},geometryRevisionId=null,nodeId=crypto.randomUUID()}){
    if(this.allowedTypes.size&&!this.allowedTypes.has(type)) throw new Error(`Unsupported semantic geometry type: ${type}`);
    if(this.nodes.has(nodeId)) throw new Error(`Semantic node already exists: ${nodeId}`);
    const node={nodeId,caseId,type,label,metadata:clone(metadata),geometryRevisionId,createdAt:now(),updatedAt:now()};
    this.nodes.set(nodeId,node); return clone(node);
  }
  updateNode(nodeId,patch){
    const node=this.nodes.get(nodeId); if(!node) throw new Error(`Unknown semantic node: ${nodeId}`);
    Object.assign(node,clone(patch),{updatedAt:now()}); return clone(node);
  }
  connect({fromNodeId,toNodeId,relationship,metadata={}}){
    if(!this.nodes.has(fromNodeId)||!this.nodes.has(toNodeId)) throw new Error("Both semantic nodes must exist.");
    const edgeId=crypto.randomUUID();
    const edge={edgeId,fromNodeId,toNodeId,relationship,metadata:clone(metadata),createdAt:now()};
    this.edges.set(edgeId,edge); return clone(edge);
  }
  neighborhood(nodeId){
    if(!this.nodes.has(nodeId)) return null;
    const edges=[...this.edges.values()].filter(e=>e.fromNodeId===nodeId||e.toNodeId===nodeId);
    const neighborIds=new Set(edges.flatMap(e=>[e.fromNodeId,e.toNodeId]).filter(id=>id!==nodeId));
    return {node:clone(this.nodes.get(nodeId)),edges:edges.map(clone),neighbors:[...neighborIds].map(id=>clone(this.nodes.get(id)))};
  }
  caseGraph(caseId){
    const nodes=[...this.nodes.values()].filter(n=>n.caseId===caseId);
    const ids=new Set(nodes.map(n=>n.nodeId));
    const edges=[...this.edges.values()].filter(e=>ids.has(e.fromNodeId)&&ids.has(e.toNodeId));
    return {caseId,nodes:nodes.map(clone),edges:edges.map(clone)};
  }
}

export class FeatureTree{
  constructor(){this.trees=new Map();}
  initialize(caseId){
    if(!this.trees.has(caseId)) this.trees.set(caseId,{caseId,features:[],activeFeatureId:null,updatedAt:now()});
    return this.get(caseId);
  }
  add({caseId,featureType,label,parameters={},inputSubjectIds=[],outputSubjectIds=[],commandId=null,createdBy="SYSTEM"}){
    this.initialize(caseId);
    const tree=this.trees.get(caseId);
    const parentFeatureId=tree.activeFeatureId;
    const feature={
      featureId:crypto.randomUUID(),caseId,featureType,label,parameters:clone(parameters),
      inputSubjectIds:[...inputSubjectIds],outputSubjectIds:[...outputSubjectIds],
      parentFeatureId,commandId,createdBy,status:"ACTIVE",createdAt:now()
    };
    tree.features.push(feature); tree.activeFeatureId=feature.featureId; tree.updatedAt=now();
    return clone(feature);
  }
  suppress(caseId,featureId){
    const tree=this.trees.get(caseId); const feature=tree?.features.find(f=>f.featureId===featureId);
    if(!feature) throw new Error(`Unknown feature: ${featureId}`);
    feature.status="SUPPRESSED"; tree.updatedAt=now(); return clone(feature);
  }
  get(caseId){const tree=this.trees.get(caseId);return tree?clone(tree):null;}
}

export class ConstraintPropagationEngine{
  constructor(config){
    this.constraints=new Map(config.constraints.map(c=>[c.constraintId,clone(c)]));
    this.states=new Map();
  }
  initialize(caseId){
    if(!this.states.has(caseId)){
      this.states.set(caseId,new Map([...this.constraints.keys()].map(id=>[id,{constraintId:id,status:"NOT_EVALUATED",stale:true,updatedAt:now()}])));
    }
  }
  recordEvaluation(caseId,constraintId,{status,evidenceId=null}){
    this.initialize(caseId);
    if(!this.constraints.has(constraintId)) throw new Error(`Unknown constraint: ${constraintId}`);
    const state={constraintId,status,stale:false,evidenceId,updatedAt:now()};
    this.states.get(caseId).set(constraintId,state); return clone(state);
  }
  invalidateByDependency(caseId,dependencyKey){
    this.initialize(caseId);
    const invalidated=new Set();
    const queue=[dependencyKey];
    while(queue.length){
      const key=queue.shift();
      for(const constraint of this.constraints.values()){
        if(constraint.dependsOn.includes(key)&&!invalidated.has(constraint.constraintId)){
          invalidated.add(constraint.constraintId);
          const current=this.states.get(caseId).get(constraint.constraintId);
          this.states.get(caseId).set(constraint.constraintId,{...current,stale:true,status:"NOT_EVALUATED",updatedAt:now()});
          for(const downstream of constraint.invalidates) queue.push(downstream);
        }
      }
    }
    return [...invalidated];
  }
  snapshot(caseId){
    this.initialize(caseId);
    return [...this.states.get(caseId).values()].map(clone);
  }
}

export class DesignVariantRepository{
  constructor(){this.cases=new Map();}
  initialize(caseId){
    if(!this.cases.has(caseId)){
      const variant={variantId:crypto.randomUUID(),caseId,name:"Primary Design",branchName:"main",status:"DRAFT",featureSnapshot:null,evidenceIds:[],createdAt:now(),updatedAt:now()};
      this.cases.set(caseId,new Map([[variant.variantId,variant]]));
    }
    return this.list(caseId);
  }
  create({caseId,name,branchName,featureSnapshot=null,evidenceIds=[]}){
    this.initialize(caseId);
    const variant={variantId:crypto.randomUUID(),caseId,name,branchName,status:"DRAFT",featureSnapshot:clone(featureSnapshot),evidenceIds:[...evidenceIds],createdAt:now(),updatedAt:now()};
    this.cases.get(caseId).set(variant.variantId,variant); return clone(variant);
  }
  setStatus(caseId,variantId,status){
    const variant=this.cases.get(caseId)?.get(variantId); if(!variant) throw new Error(`Unknown design variant: ${variantId}`);
    variant.status=status;variant.updatedAt=now();return clone(variant);
  }
  compare(caseId,variantAId,variantBId){
    const map=this.cases.get(caseId); const a=map?.get(variantAId),b=map?.get(variantBId);
    if(!a||!b) throw new Error("Both variants must exist.");
    return {
      caseId,variantA:clone(a),variantB:clone(b),
      differences:{
        branchChanged:a.branchName!==b.branchName,
        featureSnapshotChanged:JSON.stringify(a.featureSnapshot)!==JSON.stringify(b.featureSnapshot),
        evidenceOnlyInA:a.evidenceIds.filter(id=>!b.evidenceIds.includes(id)),
        evidenceOnlyInB:b.evidenceIds.filter(id=>!a.evidenceIds.includes(id))
      }
    };
  }
  list(caseId){return [...(this.cases.get(caseId)?.values()??[])].map(clone);}
}

export class ManufacturingTwin{
  constructor(){this.cases=new Map();}
  initialize(caseId){
    if(!this.cases.has(caseId)) this.cases.set(caseId,{caseId,currentStage:"DESIGN",stageHistory:[],materialLots:[],machineRuns:[],qualityEvidenceIds:[],updatedAt:now()});
    return this.get(caseId);
  }
  recordStage({caseId,stage,status,actorId,evidenceIds=[],metadata={}}){
    this.initialize(caseId);
    const twin=this.cases.get(caseId);
    const record={recordId:crypto.randomUUID(),stage,status,actorId,evidenceIds:[...evidenceIds],metadata:clone(metadata),recordedAt:now()};
    twin.currentStage=stage;twin.stageHistory.push(record);twin.updatedAt=now();
    return clone(record);
  }
  attachMaterialLot(caseId,lot){this.initialize(caseId);this.cases.get(caseId).materialLots.push(clone(lot));return this.get(caseId);}
  attachMachineRun(caseId,run){this.initialize(caseId);this.cases.get(caseId).machineRuns.push(clone(run));return this.get(caseId);}
  attachQualityEvidence(caseId,evidenceId){this.initialize(caseId);this.cases.get(caseId).qualityEvidenceIds.push(evidenceId);return this.get(caseId);}
  get(caseId){const twin=this.cases.get(caseId);return twin?clone(twin):null;}
}

export class GeometryIntelligenceService{
  constructor({graph,features,constraints,variants,manufacturingTwin}){
    this.graph=graph;this.features=features;this.constraints=constraints;this.variants=variants;this.manufacturingTwin=manufacturingTwin;
    this.evidence=new Map();
  }
  initializeCase(caseId){
    this.features.initialize(caseId);this.constraints.initialize(caseId);this.variants.initialize(caseId);this.manufacturingTwin.initialize(caseId);
    return this.snapshot(caseId);
  }
  addEvidence(input){
    const evidence=EngineeringEvidenceFactory.create(input);this.evidence.set(evidence.evidenceId,evidence);
    this.manufacturingTwin.attachQualityEvidence(evidence.caseId,evidence.evidenceId);
    return clone(evidence);
  }
  snapshot(caseId){
    return {
      semanticGraph:this.graph.caseGraph(caseId),
      featureTree:this.features.get(caseId),
      constraints:this.constraints.snapshot(caseId),
      variants:this.variants.list(caseId),
      manufacturingTwin:this.manufacturingTwin.get(caseId),
      evidence:[...this.evidence.values()].filter(e=>e.caseId===caseId).map(clone)
    };
  }
}
