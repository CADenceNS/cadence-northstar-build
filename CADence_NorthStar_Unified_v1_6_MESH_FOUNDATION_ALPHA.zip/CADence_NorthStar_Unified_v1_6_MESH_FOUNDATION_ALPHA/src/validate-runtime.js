import fs from "node:fs";
const runtime=JSON.parse(fs.readFileSync(new URL("../config/runtime.json",import.meta.url),"utf8"));
const rules=JSON.parse(fs.readFileSync(new URL("../config/clinical-rules.json",import.meta.url),"utf8"));
const profiles=JSON.parse(fs.readFileSync(new URL("../config/manufacturing-profiles.json",import.meta.url),"utf8"));
if(runtime.caseStates.length<10) throw new Error("Case-state model is incomplete.");
for(const state of runtime.caseStates){
  if(!(state in runtime.stateTransitions)) throw new Error(`Missing transitions for ${state}`);
}
if(runtime.commandTypes.length<15) throw new Error("Command catalog is incomplete.");
if(runtime.governanceRequiredFields.length<5) throw new Error("Governance contract is incomplete.");
if(rules.ruleSets.length<2) throw new Error("Clinical rule library requires at least two rule sets.");
for(const set of rules.ruleSets){
  if(!set.ruleSetId||!set.version||set.rules.length===0) throw new Error(`Invalid rule set ${set.ruleSetId}`);
}
if(profiles.profiles.length<2) throw new Error("Manufacturing profile library requires at least two profiles.");
console.log("NorthStar Core Runtime Alpha validation PASS");
