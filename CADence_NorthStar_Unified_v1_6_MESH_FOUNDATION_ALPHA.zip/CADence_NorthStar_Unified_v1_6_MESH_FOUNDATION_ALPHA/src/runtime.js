import crypto from "node:crypto";

const clone=value=>structuredClone(value);
const now=()=>new Date().toISOString();

export class GovernanceLedger{
  constructor(){this.records=[];}
  record({actionType,entityType,entityId,actorId,actorRole,reason,source,correlationId,metadata={}}){
    for(const [key,value] of Object.entries({actorId,actorRole,reason,source,correlationId})){
      if(typeof value!=="string"||value.trim()==="") throw new Error(`Governance field ${key} is required.`);
    }
    const record={
      governanceId:crypto.randomUUID(),actionType,entityType,entityId,
      actorId,actorRole,reason,source,correlationId,metadata:clone(metadata),recordedAt:now()
    };
    this.records.push(record);
    return clone(record);
  }
  list(entityId=null){
    return this.records.filter(r=>!entityId||r.entityId===entityId).map(clone);
  }
}

export class ResourceManager{
  constructor(capacity={CPU:4,GPU:0,MEMORY_GB:16,STORAGE_GB:100,WORKER:4}){
    this.capacity={...capacity};
    this.allocations=new Map();
  }
  used(){
    const total={CPU:0,GPU:0,MEMORY_GB:0,STORAGE_GB:0,WORKER:0};
    for(const allocation of this.allocations.values()){
      for(const [kind,amount] of Object.entries(allocation.resources)) total[kind]=(total[kind]??0)+amount;
    }
    return total;
  }
  available(){
    const used=this.used();
    return Object.fromEntries(Object.entries(this.capacity).map(([k,v])=>[k,v-(used[k]??0)]));
  }
  canAllocate(resources){
    const available=this.available();
    return Object.entries(resources).every(([kind,amount])=>(available[kind]??0)>=amount);
  }
  allocate(ownerId,resources){
    if(this.allocations.has(ownerId)) throw new Error(`Resources already allocated to ${ownerId}.`);
    if(!this.canAllocate(resources)) return false;
    this.allocations.set(ownerId,{ownerId,resources:clone(resources),allocatedAt:now()});
    return true;
  }
  release(ownerId){return this.allocations.delete(ownerId);}
  snapshot(){return {capacity:clone(this.capacity),used:this.used(),available:this.available(),allocations:[...this.allocations.values()].map(clone)};}
}

export class CaseStateMachine{
  constructor({states,transitions}){
    this.states=new Set(states);
    this.transitions=new Map(Object.entries(transitions));
    this.caseStates=new Map();
  }
  initialize(caseId,state="RECEIVED"){
    if(!this.states.has(state)) throw new Error(`Unknown case state: ${state}`);
    if(this.caseStates.has(caseId)) throw new Error(`Case state already exists: ${caseId}`);
    const record={caseId,state,previousState:null,updatedAt:now()};
    this.caseStates.set(caseId,record);
    return clone(record);
  }
  transition(caseId,toState){
    const current=this.caseStates.get(caseId);
    if(!current) throw new Error(`Unknown case state: ${caseId}`);
    if(!this.states.has(toState)) throw new Error(`Unknown destination state: ${toState}`);
    const allowed=this.transitions.get(current.state)??[];
    if(!allowed.includes(toState)) throw new Error(`Invalid transition ${current.state} -> ${toState}`);
    const next={caseId,state:toState,previousState:current.state,updatedAt:now()};
    this.caseStates.set(caseId,next);
    return clone(next);
  }
  get(caseId){const value=this.caseStates.get(caseId);return value?clone(value):null;}
}

export class RevisionRepository{
  constructor(){this.cases=new Map();}
  initialize(caseId,createdBy="SYSTEM"){
    if(this.cases.has(caseId)) return this.get(caseId);
    const rootRevision={
      revisionId:crypto.randomUUID(),caseId,branchName:"main",parentRevisionIds:[],
      commandIds:[],label:"Initial case revision",createdBy,createdAt:now(),status:"ACTIVE"
    };
    this.cases.set(caseId,{
      branches:new Map([["main",{branchName:"main",headRevisionId:rootRevision.revisionId,createdAt:now()}]]),
      revisions:new Map([[rootRevision.revisionId,rootRevision]]),
      checkedOutBranch:"main"
    });
    return this.get(caseId);
  }
  createRevision({caseId,commandId,label,createdBy}){
    const repo=this.cases.get(caseId); if(!repo) throw new Error(`Unknown revision repository: ${caseId}`);
    const branch=repo.branches.get(repo.checkedOutBranch);
    const revision={
      revisionId:crypto.randomUUID(),caseId,branchName:repo.checkedOutBranch,
      parentRevisionIds:[branch.headRevisionId],commandIds:[commandId],
      label:label??"CAD change",createdBy,createdAt:now(),status:"ACTIVE"
    };
    repo.revisions.set(revision.revisionId,revision);
    branch.headRevisionId=revision.revisionId;
    return clone(revision);
  }
  createBranch({caseId,branchName,fromRevisionId=null}){
    const repo=this.cases.get(caseId); if(!repo) throw new Error(`Unknown revision repository: ${caseId}`);
    if(repo.branches.has(branchName)) throw new Error(`Branch already exists: ${branchName}`);
    const source=fromRevisionId??repo.branches.get(repo.checkedOutBranch).headRevisionId;
    if(!repo.revisions.has(source)) throw new Error(`Unknown revision: ${source}`);
    repo.branches.set(branchName,{branchName,headRevisionId:source,createdAt:now()});
    return clone(repo.branches.get(branchName));
  }
  checkout(caseId,branchName){
    const repo=this.cases.get(caseId); if(!repo?.branches.has(branchName)) throw new Error(`Unknown branch: ${branchName}`);
    repo.checkedOutBranch=branchName;
    return this.get(caseId);
  }
  merge({caseId,sourceBranch,targetBranch,createdBy}){
    const repo=this.cases.get(caseId); if(!repo) throw new Error(`Unknown revision repository: ${caseId}`);
    const source=repo.branches.get(sourceBranch), target=repo.branches.get(targetBranch);
    if(!source||!target) throw new Error("Source and target branches must exist.");
    const revision={
      revisionId:crypto.randomUUID(),caseId,branchName:targetBranch,
      parentRevisionIds:[target.headRevisionId,source.headRevisionId],commandIds:[],
      label:`Merge ${sourceBranch} into ${targetBranch}`,createdBy,createdAt:now(),status:"ACTIVE"
    };
    repo.revisions.set(revision.revisionId,revision);
    target.headRevisionId=revision.revisionId;
    return clone(revision);
  }
  get(caseId){
    const repo=this.cases.get(caseId); if(!repo) return null;
    return {
      checkedOutBranch:repo.checkedOutBranch,
      branches:[...repo.branches.values()].map(clone),
      revisions:[...repo.revisions.values()].sort((a,b)=>a.createdAt.localeCompare(b.createdAt)).map(clone)
    };
  }
}

export class ClinicalRuleLibrary{
  constructor(config){
    this.ruleSets=new Map(config.ruleSets.map(r=>[r.ruleSetId,clone(r)]));
  }
  get(ruleSetId){const value=this.ruleSets.get(ruleSetId);if(!value) throw new Error(`Unknown rule set: ${ruleSetId}`);return clone(value);}
  evaluate(ruleSetId,metrics){
    const ruleSet=this.get(ruleSetId);
    const results=ruleSet.rules.map(rule=>{
      const actual=metrics[rule.ruleId];
      let passed=false;
      if(rule.operator===">=") passed=typeof actual==="number"&&actual>=rule.value;
      else if(rule.operator==="<=") passed=typeof actual==="number"&&actual<=rule.value;
      else if(rule.operator==="==") passed=actual===rule.value;
      else throw new Error(`Unsupported operator: ${rule.operator}`);
      return {...clone(rule),actual,passed};
    });
    return {ruleSetId,version:ruleSet.version,passed:results.every(r=>r.passed),results,evaluatedAt:now()};
  }
}

export class ManufacturingProfileRegistry{
  constructor(config){this.profiles=new Map(config.profiles.map(p=>[p.profileId,clone(p)]));}
  get(profileId){const value=this.profiles.get(profileId);if(!value) throw new Error(`Unknown manufacturing profile: ${profileId}`);return clone(value);}
  list(){return [...this.profiles.values()].map(clone);}
  select({process,material}){
    const profile=[...this.profiles.values()].find(p=>p.process===process&&p.materials.includes(material));
    if(!profile) throw new Error(`No manufacturing profile for ${process}/${material}`);
    return clone(profile);
  }
}

export class JobEngine{
  constructor({resourceManager,eventPublisher=()=>{}}){
    this.resourceManager=resourceManager;
    this.eventPublisher=eventPublisher;
    this.jobs=new Map();
  }
  create({caseId,jobType,dependencies=[],resources={CPU:1,WORKER:1},payload={},priority=50,maxAttempts=3}){
    for(const dep of dependencies) if(!this.jobs.has(dep)) throw new Error(`Unknown dependency: ${dep}`);
    const job={
      jobId:crypto.randomUUID(),caseId,jobType,dependencies:[...dependencies],resources:clone(resources),
      payload:clone(payload),priority,maxAttempts,attempts:0,status:dependencies.length?"BLOCKED":"QUEUED",
      progress:0,error:null,createdAt:now(),updatedAt:now()
    };
    this.jobs.set(job.jobId,job);
    this.refresh();
    return clone(job);
  }
  refresh(){
    for(const job of this.jobs.values()){
      if(job.status!=="BLOCKED") continue;
      const deps=job.dependencies.map(id=>this.jobs.get(id));
      if(deps.some(d=>d?.status==="FAILED"||d?.status==="CANCELLED")){
        job.status="CANCELLED";job.error="Dependency did not complete.";job.updatedAt=now();
      }else if(deps.every(d=>d?.status==="SUCCEEDED")){
        job.status="QUEUED";job.updatedAt=now();
      }
    }
  }
  start(jobId){
    this.refresh();
    const job=this.jobs.get(jobId); if(!job) throw new Error(`Unknown job: ${jobId}`);
    if(job.status!=="QUEUED") throw new Error(`Job ${jobId} is not queued.`);
    if(!this.resourceManager.allocate(jobId,job.resources)) throw new Error(`Insufficient resources for job ${jobId}.`);
    job.status="RUNNING";job.attempts+=1;job.startedAt=now();job.updatedAt=now();
    this.eventPublisher("JOB_STARTED",job);
    return clone(job);
  }
  updateProgress(jobId,progress){
    const job=this.jobs.get(jobId); if(!job||job.status!=="RUNNING") throw new Error("Only running jobs can report progress.");
    if(typeof progress!=="number"||progress<0||progress>100) throw new Error("Progress must be between 0 and 100.");
    job.progress=progress;job.updatedAt=now();
    return clone(job);
  }
  complete(jobId,result={}){
    const job=this.jobs.get(jobId); if(!job||job.status!=="RUNNING") throw new Error("Only running jobs can complete.");
    job.status="SUCCEEDED";job.progress=100;job.result=clone(result);job.completedAt=now();job.updatedAt=now();
    this.resourceManager.release(jobId);this.refresh();this.eventPublisher("JOB_COMPLETED",job);
    return clone(job);
  }
  fail(jobId,error){
    const job=this.jobs.get(jobId); if(!job||job.status!=="RUNNING") throw new Error("Only running jobs can fail.");
    job.status="FAILED";job.error=String(error);job.updatedAt=now();this.resourceManager.release(jobId);this.refresh();
    this.eventPublisher("JOB_FAILED",job);return clone(job);
  }
  retry(jobId){
    const job=this.jobs.get(jobId); if(!job||job.status!=="FAILED") throw new Error("Only failed jobs can retry.");
    if(job.attempts>=job.maxAttempts) throw new Error("Job retry limit reached.");
    job.status="QUEUED";job.error=null;job.progress=0;job.updatedAt=now();
    return clone(job);
  }
  get(jobId){const value=this.jobs.get(jobId);return value?clone(value):null;}
  list(caseId=null){return [...this.jobs.values()].filter(j=>!caseId||j.caseId===caseId).sort((a,b)=>b.priority-a.priority||a.createdAt.localeCompare(b.createdAt)).map(clone);}
}

export class CommandRuntime{
  constructor({allowedCommands,stateMachine,revisions,jobs,rules,profiles,governance,publishEvent=()=>{}}){
    this.allowedCommands=new Set(allowedCommands);
    this.stateMachine=stateMachine;this.revisions=revisions;this.jobs=jobs;
    this.rules=rules;this.profiles=profiles;this.governance=governance;this.publishEvent=publishEvent;
    this.commands=new Map();
  }
  execute({commandType,caseId,payload={},actorId,actorRole,reason,source="API",correlationId=crypto.randomUUID(),idempotencyKey=null}){
    if(!this.allowedCommands.has(commandType)) throw new Error(`Unsupported commandType: ${commandType}`);
    if(idempotencyKey){
      const existing=[...this.commands.values()].find(c=>c.idempotencyKey===idempotencyKey);
      if(existing) return clone(existing);
    }
    const command={
      commandId:crypto.randomUUID(),commandType,caseId,payload:clone(payload),actorId,actorRole,
      reason,source,correlationId,idempotencyKey,status:"ACCEPTED",createdAt:now()
    };
    try{
      command.result=this.dispatch(command);
      command.status="SUCCEEDED";command.completedAt=now();
      this.governance.record({
        actionType:commandType,entityType:"CASE",entityId:caseId,
        actorId,actorRole,reason,source,correlationId,metadata:{commandId:command.commandId}
      });
      this.publishEvent("COMMAND_SUCCEEDED",command);
    }catch(error){
      command.status="FAILED";command.error=error.message;command.completedAt=now();
      this.publishEvent("COMMAND_FAILED",command);
      this.commands.set(command.commandId,command);
      throw error;
    }
    this.commands.set(command.commandId,command);
    return clone(command);
  }
  dispatch(command){
    const {commandType,caseId,payload,actorId}=command;
    switch(commandType){
      case "CREATE_CASE":
        this.stateMachine.initialize(caseId);
        this.revisions.initialize(caseId,actorId);
        return {state:this.stateMachine.get(caseId),revisions:this.revisions.get(caseId)};
      case "TRANSITION_CASE":
        return this.stateMachine.transition(caseId,payload.toState);
      case "CREATE_REVISION":
        return this.revisions.createRevision({caseId,commandId:command.commandId,label:payload.label,createdBy:actorId});
      case "CREATE_BRANCH":
        return this.revisions.createBranch({caseId,branchName:payload.branchName,fromRevisionId:payload.fromRevisionId});
      case "CHECKOUT_REVISION":
        return this.revisions.checkout(caseId,payload.branchName);
      case "MERGE_BRANCH":
        return this.revisions.merge({caseId,sourceBranch:payload.sourceBranch,targetBranch:payload.targetBranch,createdBy:actorId});
      case "APPLY_CLINICAL_RULESET":
        return this.rules.evaluate(payload.ruleSetId,payload.metrics??{});
      case "CREATE_JOB":
        return this.jobs.create({caseId,...payload});
      case "START_JOB":
        return this.jobs.start(payload.jobId);
      case "UPDATE_JOB_PROGRESS":
        return this.jobs.updateProgress(payload.jobId,payload.progress);
      case "COMPLETE_JOB":
        return this.jobs.complete(payload.jobId,payload.result);
      case "FAIL_JOB":
        return this.jobs.fail(payload.jobId,payload.error);
      case "RETRY_JOB":
        return this.jobs.retry(payload.jobId);
      case "ASSIGN_MANUFACTURING_PROFILE":
        return this.profiles.get(payload.profileId);
      default:
        return {accepted:true,payload:clone(payload)};
    }
  }
  list(caseId=null){return [...this.commands.values()].filter(c=>!caseId||c.caseId===caseId).map(clone);}
}
