import fs from "node:fs";
const c=JSON.parse(fs.readFileSync(new URL("../config/guided-workflows.json",import.meta.url),"utf8"));
const requiredModalities=["FIXED","IMPLANT","REMOVABLE","ORTHO","SLEEP","DIAGNOSTICS"];
for(const modality of requiredModalities){
  const steps=c.workflows[modality];
  if(!Array.isArray(steps)||steps.length<8) throw new Error(`${modality} requires a complete guided workflow.`);
  const ids=new Set(steps.map(s=>s.stepId));
  for(const step of steps){
    if(!c.modules.includes(step.module)) throw new Error(`${modality}/${step.stepId} has unknown module ${step.module}`);
    if(typeof step.instruction!=="string"||step.instruction.length<40) throw new Error(`${modality}/${step.stepId} instruction is incomplete.`);
    if(typeof step.successCriteria!=="string"||step.successCriteria.length<30) throw new Error(`${modality}/${step.stepId} success criteria is incomplete.`);
    if(step.nextStepId!=="COMPLETE"&&!ids.has(step.nextStepId)) throw new Error(`${modality}/${step.stepId} references missing next step ${step.nextStepId}`);
  }
}
console.log("Guided workflow validation PASS");
