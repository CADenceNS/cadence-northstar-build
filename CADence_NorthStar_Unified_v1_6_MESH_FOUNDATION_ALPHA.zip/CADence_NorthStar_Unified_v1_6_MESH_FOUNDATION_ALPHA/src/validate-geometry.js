import fs from "node:fs";
const geometry=JSON.parse(fs.readFileSync(new URL("../config/geometry-intelligence.json",import.meta.url),"utf8"));
const network=JSON.parse(fs.readFileSync(new URL("../config/constraint-network.json",import.meta.url),"utf8"));
if(geometry.semanticTypes.length<15) throw new Error("Semantic geometry type catalog is incomplete.");
if(geometry.featureTypes.length<10) throw new Error("Feature type catalog is incomplete.");
if(!geometry.evidenceStatuses.includes("FAIL")||!geometry.evidenceStatuses.includes("REVIEW")) throw new Error("Evidence status catalog is incomplete.");
if(network.constraints.length<5) throw new Error("Constraint network is incomplete.");
for(const c of network.constraints){
  if(!c.constraintId||!c.domain||!Array.isArray(c.dependsOn)||!Array.isArray(c.invalidates)) throw new Error(`Invalid constraint ${c.constraintId}`);
}
console.log("NorthStar Geometry Intelligence Alpha validation PASS");
