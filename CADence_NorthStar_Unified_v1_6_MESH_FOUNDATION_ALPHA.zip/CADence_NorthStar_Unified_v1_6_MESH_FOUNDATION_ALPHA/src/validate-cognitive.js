import fs from "node:fs";
const config=JSON.parse(fs.readFileSync(new URL("../config/cognitive-platform.json",import.meta.url),"utf8"));
if(config.engines.length!==5) throw new Error("Exactly five cognitive engines are required.");
const engineIds=new Set();
for(const engine of config.engines){
  if(engineIds.has(engine.engineId)) throw new Error(`Duplicate engine ${engine.engineId}`);
  engineIds.add(engine.engineId);
  if(engine.subscribesTo.length===0||engine.publishes.length===0||engine.responsibilities.length<3) throw new Error(`Engine ${engine.engineId} is incomplete.`);
}
if(config.knowledgeNodeTypes.length<15) throw new Error("Knowledge graph node taxonomy is incomplete.");
if(config.knowledgeEdgeTypes.length<15) throw new Error("Knowledge graph edge taxonomy is incomplete.");
if(config.recommendationRequirements.length<10) throw new Error("Explainable recommendation schema is incomplete.");
console.log("NorthStar Cognitive Platform validation PASS");
