import fs from "node:fs";
const config=JSON.parse(fs.readFileSync(new URL("../config/mesh-foundation.json",import.meta.url),"utf8"));
if(!config.supportedFormats.includes("STL_ASCII")||!config.supportedFormats.includes("STL_BINARY")) throw new Error("Both ASCII and binary STL support are required.");
if(config.analysisCapabilities.length<8) throw new Error("Mesh analysis capability catalog is incomplete.");
for(const key of ["maxDegenerateTriangleRatio","maxBoundaryEdgeRatioClosedMesh","maxNonManifoldEdgeRatio","minNormalAgreementRatio"]){
  if(typeof config.qualityThresholds[key]!=="number") throw new Error(`Missing mesh threshold ${key}`);
}
console.log("NorthStar Mesh Foundation Alpha validation PASS");
