import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";
import {NorthStarEventBus} from "./event-bus.js";
import {GuidedCompletionEngine} from "./guided-engine.js";
import {wireNorthStarModules} from "./integration.js";
import {DurableJsonStore} from "./store.js";
import {determinePlan,assertCaseEnvelope} from "./daas/rules.js";
import {evaluateQuality} from "./daas/quality.js";
import {buildManifest} from "./daas/manifest.js";
import {analyzeCase} from "./copilot.js";
import {KnowledgeGraph,CognitiveOrchestrator} from "./cognitive-platform.js";
import {
  GovernanceLedger,ResourceManager,CaseStateMachine,RevisionRepository,
  ClinicalRuleLibrary,ManufacturingProfileRegistry,JobEngine,CommandRuntime
} from "./runtime.js";
import {
  SemanticGeometryGraph,FeatureTree,ConstraintPropagationEngine,
  DesignVariantRepository,ManufacturingTwin,GeometryIntelligenceService
} from "./geometry-intelligence.js";
import {StlParser,MeshAnalyzer,MeshQualityEngine,MeshRepository} from "./mesh-foundation.js";

const here=path.dirname(fileURLToPath(import.meta.url));
const config=JSON.parse(fs.readFileSync(path.join(here,"../config/guided-workflows.json"),"utf8"));
const store=new DurableJsonStore(process.env.STATE_FILE??path.join(here,"../data/state.json"));
const bus=new NorthStarEventBus({allowedEvents:config.eventTypes,allowedModules:config.modules});
const engine=new GuidedCompletionEngine({store});
const integration=wireNorthStarModules(bus,engine);
const knowledgeGraph=new KnowledgeGraph({store});
const cognitive=new CognitiveOrchestrator({bus,graph:knowledgeGraph});
const runtimeConfig=JSON.parse(fs.readFileSync(path.join(here,"../config/runtime.json"),"utf8"));
const clinicalRulesConfig=JSON.parse(fs.readFileSync(path.join(here,"../config/clinical-rules.json"),"utf8"));
const manufacturingProfilesConfig=JSON.parse(fs.readFileSync(path.join(here,"../config/manufacturing-profiles.json"),"utf8"));
const governance=new GovernanceLedger();
const resources=new ResourceManager();
const caseStateMachine=new CaseStateMachine({states:runtimeConfig.caseStates,transitions:runtimeConfig.stateTransitions});
const revisions=new RevisionRepository();
const clinicalRules=new ClinicalRuleLibrary(clinicalRulesConfig);
const manufacturingProfiles=new ManufacturingProfileRegistry(manufacturingProfilesConfig);
const geometryConfig=JSON.parse(fs.readFileSync(path.join(here,"../config/geometry-intelligence.json"),"utf8"));
const constraintConfig=JSON.parse(fs.readFileSync(path.join(here,"../config/constraint-network.json"),"utf8"));
const semanticGeometry=new SemanticGeometryGraph({allowedTypes:geometryConfig.semanticTypes});
const geometryFeatures=new FeatureTree();
const constraintPropagation=new ConstraintPropagationEngine(constraintConfig);
const designVariants=new DesignVariantRepository();
const manufacturingTwin=new ManufacturingTwin();
const meshConfig=JSON.parse(fs.readFileSync(path.join(here,"../config/mesh-foundation.json"),"utf8"));
const meshQuality=new MeshQualityEngine(meshConfig);
const meshRepository=new MeshRepository();
const geometryIntelligence=new GeometryIntelligenceService({
  graph:semanticGeometry,features:geometryFeatures,constraints:constraintPropagation,
  variants:designVariants,manufacturingTwin
});
const runtimeEvent=(eventType,record)=>{
  const map={JOB_STARTED:"JOB_STARTED",JOB_COMPLETED:"JOB_COMPLETED",JOB_FAILED:"JOB_FAILED"};
  if(map[eventType]) publishAndPersist({eventType:map[eventType],sourceModule:"PLATFORM_RUNTIME",caseId:record.caseId,payload:{jobId:record.jobId,status:record.status,progress:record.progress},actorId:"PLATFORM_RUNTIME"});
};
const jobs=new JobEngine({resourceManager:resources,eventPublisher:runtimeEvent});
const commandRuntime=new CommandRuntime({
  allowedCommands:runtimeConfig.commandTypes,stateMachine:caseStateMachine,revisions,jobs,
  rules:clinicalRules,profiles:manufacturingProfiles,governance,
  publishEvent:(eventType,command)=>{
    publishAndPersist({eventType,sourceModule:"PLATFORM_RUNTIME",caseId:command.caseId,payload:{commandId:command.commandId,commandType:command.commandType,status:command.status},actorId:command.actorId});
  }
});

bus.on("*",event=>store.appendEvent(event));

const HOST=process.env.HOST??"127.0.0.1";
const PORT=Number.parseInt(process.env.PORT??"8090",10);
const publicDir=path.join(here,"../public");

function send(res,status,payload){
  const body=JSON.stringify(payload,null,2);
  res.writeHead(status,{"content-type":"application/json; charset=utf-8","content-length":Buffer.byteLength(body),"cache-control":"no-store"});
  res.end(body);
}
function sendFile(res,filePath,contentType){
  const data=fs.readFileSync(filePath);
  res.writeHead(200,{"content-type":contentType,"content-length":data.length,"cache-control":"no-store"});
  res.end(data);
}
async function readJson(req){
  const chunks=[];let size=0;
  for await(const chunk of req){
    size+=chunk.length;
    if(size>5_000_000) throw Object.assign(new Error("Request exceeds 5 MB."),{statusCode:413});
    chunks.push(chunk);
  }
  if(size===0) throw Object.assign(new Error("JSON body required."),{statusCode:400});
  try{return JSON.parse(Buffer.concat(chunks).toString("utf8"));}catch{throw Object.assign(new Error("Malformed JSON."),{statusCode:400});}
}
function publishAndPersist(eventInput){
  const event=bus.publish(eventInput);
  for(const delivery of integration.getDeliveries(event.caseId).filter(d=>d.deliveryId===event.eventId||d.deliveryId.startsWith(`${event.eventId}:`))){
    store.appendDelivery(delivery);
  }
  return event;
}

const server=http.createServer(async(req,res)=>{
  const requestId=crypto.randomUUID();
  try{
    const url=new URL(req.url,`http://${req.headers.host??"localhost"}`);
    if(req.method==="GET"&&url.pathname==="/") return sendFile(res,path.join(publicDir,"index.html"),"text/html; charset=utf-8");
    if(req.method==="GET"&&url.pathname==="/health") return send(res,200,{status:"ok",service:"cadence-northstar-unified",version:"1.6.0",requestId});
    if(req.method==="GET"&&url.pathname==="/v1/cases") return send(res,200,{requestId,cases:store.listCases().map(c=>({...c,guidance:engine.getGuidance(c.caseId)}))});
    if(req.method==="POST"&&url.pathname==="/v1/cases"){
      const body=await readJson(req);
      const guidance=engine.createCase(body);
      cognitive.registerCase({caseId:body.caseId,modality:body.modality,doctorId:body.doctorId??null,patientId:body.patientId??null});
      geometryIntelligence.initializeCase(body.caseId);
      commandRuntime.execute({
        commandType:"CREATE_CASE",caseId:body.caseId,payload:{modality:body.modality},
        actorId:body.createdBy??"SYSTEM",actorRole:body.createdByRole??"CASE_INTAKE",
        reason:"Create the canonical runtime case state and initial revision.",
        source:"CASE_API",correlationId:requestId,idempotencyKey:`CREATE_CASE:${body.caseId}`
      });
      publishAndPersist({eventType:"CASE_CREATED",sourceModule:"CASES",caseId:body.caseId,payload:{modality:body.modality},actorId:body.createdBy??"SYSTEM"});
      return send(res,201,{requestId,guidance});
    }
    const guidanceMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/guidance$/);
    if(req.method==="GET"&&guidanceMatch) return send(res,200,{requestId,guidance:engine.getGuidance(decodeURIComponent(guidanceMatch[1]))});
    const completeMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/steps\/([^/]+)\/complete$/);
    if(req.method==="POST"&&completeMatch){
      const body=await readJson(req);
      const caseId=decodeURIComponent(completeMatch[1]);
      const stepId=decodeURIComponent(completeMatch[2]);
      const guidance=engine.completeStep({caseId,stepId,evidence:body.evidence,completedBy:body.completedBy});
      publishAndPersist({eventType:"TRAINING_CONFIRMED",sourceModule:"KNOWLEDGE_CENTER",caseId,payload:{stepId},actorId:body.completedBy});
      return send(res,200,{requestId,guidance});
    }
    if(req.method==="POST"&&url.pathname==="/v1/events"){
      const event=publishAndPersist(await readJson(req));
      return send(res,202,{requestId,event});
    }
    const timelineMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/timeline$/);
    if(req.method==="GET"&&timelineMatch){
      const caseId=decodeURIComponent(timelineMatch[1]);
      return send(res,200,{requestId,events:store.getEvents(caseId),deliveries:store.getDeliveries(caseId)});
    }

    const twinMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/digital-twin$/);
    if(req.method==="GET"&&twinMatch){
      return send(res,200,{requestId,digitalTwin:cognitive.getTwin(decodeURIComponent(twinMatch[1]))});
    }
    const recMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/recommendations$/);
    if(req.method==="GET"&&recMatch){
      return send(res,200,{requestId,recommendations:cognitive.getRecommendations(decodeURIComponent(recMatch[1]))});
    }
    const graphMatch=url.pathname.match(/^\/v1\/knowledge\/nodes\/([^/]+)\/neighborhood$/);
    if(req.method==="GET"&&graphMatch){
      return send(res,200,{requestId,neighborhood:knowledgeGraph.neighborhood(decodeURIComponent(graphMatch[1]))});
    }




    const meshAnalyzeMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/meshes\/analyze$/);
    if(req.method==="POST"&&meshAnalyzeMatch){
      const caseId=decodeURIComponent(meshAnalyzeMatch[1]); const body=await readJson(req);
      if(typeof body.stlBase64!=="string"||body.stlBase64.length===0) return send(res,400,{requestId,error:"stlBase64 is required."});
      const buffer=Buffer.from(body.stlBase64,"base64");
      const mesh=StlParser.parseBuffer(buffer,{sourceName:body.fileName??"upload.stl"});
      const analysis=MeshAnalyzer.analyze(mesh);
      const subjectId=body.subjectId??crypto.randomUUID();
      const evidenceInputs=meshQuality.evaluate({caseId,subjectId,analysis});
      const evidence=evidenceInputs.map(input=>geometryIntelligence.addEvidence(input));
      const node=semanticGeometry.addNode({
        caseId,type:"SCAN",label:body.label??body.fileName??"Imported STL",
        metadata:{format:mesh.format,analysisId:analysis.analysisId,triangleCount:analysis.triangleCount,vertexCount:analysis.vertexCount},
        geometryRevisionId:body.geometryRevisionId??null,nodeId:subjectId
      });
      const feature=geometryFeatures.add({
        caseId,featureType:"IMPORT_SCAN",label:`Import ${body.fileName??"STL"}`,
        parameters:{format:mesh.format,analysisId:analysis.analysisId},outputSubjectIds:[node.nodeId],
        createdBy:body.actorId??"SYSTEM"
      });
      const record=meshRepository.save({caseId,subjectId:node.nodeId,fileName:body.fileName??"upload.stl",format:mesh.format,analysis,evidenceIds:evidence.map(e=>e.evidenceId)});
      publishAndPersist({eventType:"SEMANTIC_GEOMETRY_UPDATED",sourceModule:"GEOMETRY_INTELLIGENCE",caseId,payload:{nodeId:node.nodeId,type:"SCAN",meshRecordId:record.meshRecordId},actorId:body.actorId??"SYSTEM"});
      return send(res,201,{requestId,meshRecord:record,node,feature,evidence});
    }
    const meshListMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/meshes$/);
    if(req.method==="GET"&&meshListMatch){
      const caseId=decodeURIComponent(meshListMatch[1]);
      return send(res,200,{requestId,meshes:meshRepository.list(caseId)});
    }

    const geometryMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/geometry-intelligence$/);
    if(req.method==="GET"&&geometryMatch){
      const caseId=decodeURIComponent(geometryMatch[1]);
      return send(res,200,{requestId,geometryIntelligence:geometryIntelligence.snapshot(caseId)});
    }
    const geometryNodeMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/semantic-geometry\/nodes$/);
    if(req.method==="POST"&&geometryNodeMatch){
      const caseId=decodeURIComponent(geometryNodeMatch[1]); const body=await readJson(req);
      const node=semanticGeometry.addNode({caseId,...body});
      publishAndPersist({eventType:"SEMANTIC_GEOMETRY_UPDATED",sourceModule:"GEOMETRY_INTELLIGENCE",caseId,payload:{nodeId:node.nodeId,type:node.type},actorId:body.actorId??"SYSTEM"});
      return send(res,201,{requestId,node});
    }
    const featureMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/geometry-features$/);
    if(req.method==="POST"&&featureMatch){
      const caseId=decodeURIComponent(featureMatch[1]); const body=await readJson(req);
      const feature=geometryFeatures.add({caseId,...body});
      publishAndPersist({eventType:"GEOMETRY_FEATURE_ADDED",sourceModule:"GEOMETRY_INTELLIGENCE",caseId,payload:{featureId:feature.featureId,featureType:feature.featureType},actorId:body.createdBy??"SYSTEM"});
      return send(res,201,{requestId,feature});
    }
    const evidenceMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/engineering-evidence$/);
    if(req.method==="POST"&&evidenceMatch){
      const caseId=decodeURIComponent(evidenceMatch[1]); const body=await readJson(req);
      const evidence=geometryIntelligence.addEvidence({caseId,...body});
      publishAndPersist({eventType:"ENGINEERING_EVIDENCE_RECORDED",sourceModule:"ENGINEERING_EVIDENCE",caseId,payload:{evidenceId:evidence.evidenceId,status:evidence.status,severity:evidence.severity},actorId:body.actorId??"SYSTEM"});
      return send(res,201,{requestId,evidence});
    }

    if(req.method==="POST"&&url.pathname==="/v1/runtime/commands"){
      const body=await readJson(req);
      const command=commandRuntime.execute(body);
      return send(res,command.status==="SUCCEEDED"?200:422,{requestId,command});
    }
    const commandsMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/commands$/);
    if(req.method==="GET"&&commandsMatch){
      const caseId=decodeURIComponent(commandsMatch[1]);
      return send(res,200,{requestId,commands:commandRuntime.list(caseId)});
    }
    const runtimeMatch=url.pathname.match(/^\/v1\/cases\/([^/]+)\/runtime$/);
    if(req.method==="GET"&&runtimeMatch){
      const caseId=decodeURIComponent(runtimeMatch[1]);
      return send(res,200,{requestId,runtime:{
        state:caseStateMachine.get(caseId),
        revisions:revisions.get(caseId),
        jobs:jobs.list(caseId),
        governance:governance.list(caseId)
      }});
    }
    if(req.method==="GET"&&url.pathname==="/v1/runtime/resources"){
      return send(res,200,{requestId,resources:resources.snapshot()});
    }
    if(req.method==="GET"&&url.pathname==="/v1/manufacturing/profiles"){
      return send(res,200,{requestId,profiles:manufacturingProfiles.list()});
    }

    if(req.method==="POST"&&url.pathname==="/v1/daas/evaluate"){
      const input=await readJson(req);
      assertCaseEnvelope(input);
      const plan=determinePlan(input);
      const quality=evaluateQuality(input,plan);
      const manifest=quality.passed?buildManifest(input,plan,quality):null;
      const registered=store.getCase(input.caseId);
      const currentGuidance=registered?engine.getGuidance(input.caseId):null;
      const copilot=analyzeCase(input,plan,quality,currentGuidance);
      publishAndPersist({
        eventType:"CLINICAL_CONFIDENCE_UPDATED",
        sourceModule:"DAAS",
        caseId:input.caseId,
        payload:{confidence:copilot.summary.overallConfidence,modality:input.modality},
        actorId:"CLINICAL_INTELLIGENCE"
      });
      for(const finding of copilot.findings){
        publishAndPersist({
          eventType:"COGNITIVE_FINDING_CREATED",
          sourceModule:"DAAS",
          caseId:input.caseId,
          payload:{...finding,modality:input.modality,variant:input.variant},
          actorId:"CLINICAL_INTELLIGENCE"
        });
      }
      if(registered){
        publishAndPersist({
          eventType:quality.passed?"AUTOMATED_DESIGN_COMPLETE":"DESIGN_CHECKPOINT_FAILED",
          sourceModule:"DAAS",
          caseId:input.caseId,
          payload:{quality,manifest},
          actorId:"DAAS"
        });
      }
      return send(res,quality.passed?200:422,{requestId,plan,quality,manifest,copilot,nextStep:currentGuidance});
    }
    return send(res,404,{error:"NotFound",message:"Route not found.",requestId});
  }catch(error){
    console.error(JSON.stringify({level:"error",requestId,message:error.message,stack:error.stack}));
    return send(res,error.statusCode??400,{error:error.name??"Error",message:error.message,requestId});
  }
});

server.listen(PORT,HOST,()=>console.info(JSON.stringify({level:"info",event:"server_started",host:HOST,port:PORT})));
for(const signal of ["SIGINT","SIGTERM"]) process.on(signal,()=>server.close(()=>process.exit(0)));
