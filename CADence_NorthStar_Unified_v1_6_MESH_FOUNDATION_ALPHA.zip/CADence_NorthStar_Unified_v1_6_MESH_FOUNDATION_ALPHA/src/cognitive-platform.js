import fs from "node:fs";
import crypto from "node:crypto";

const config=JSON.parse(fs.readFileSync(new URL("../config/cognitive-platform.json",import.meta.url),"utf8"));

const now=()=>new Date().toISOString();
const severityRank=severity=>["INFO","LOW","MEDIUM","HIGH","CRITICAL"].indexOf(severity);

export class KnowledgeGraph{
  constructor({store=null}={}){
    this.store=store;
    this.nodes=new Map();
    this.edges=new Map();
  }
  upsertNode({nodeId,nodeType,label,properties={}}){
    if(!config.knowledgeNodeTypes.includes(nodeType)) throw new Error(`Unsupported nodeType: ${nodeType}`);
    if(typeof nodeId!=="string"||nodeId.length<3) throw new Error("nodeId is required.");
    const existing=this.nodes.get(nodeId);
    const node={
      nodeId,nodeType,label:label??existing?.label??nodeId,
      properties:{...(existing?.properties??{}),...structuredClone(properties)},
      createdAt:existing?.createdAt??now(),updatedAt:now()
    };
    this.nodes.set(nodeId,node);
    return structuredClone(node);
  }
  connect({edgeId=crypto.randomUUID(),fromNodeId,toNodeId,edgeType,properties={}}){
    if(!config.knowledgeEdgeTypes.includes(edgeType)) throw new Error(`Unsupported edgeType: ${edgeType}`);
    if(!this.nodes.has(fromNodeId)) throw new Error(`Unknown fromNodeId: ${fromNodeId}`);
    if(!this.nodes.has(toNodeId)) throw new Error(`Unknown toNodeId: ${toNodeId}`);
    const edge={edgeId,fromNodeId,toNodeId,edgeType,properties:structuredClone(properties),createdAt:now()};
    this.edges.set(edgeId,edge);
    return structuredClone(edge);
  }
  neighborhood(nodeId){
    const node=this.nodes.get(nodeId);
    if(!node) throw new Error(`Unknown node: ${nodeId}`);
    const edges=[...this.edges.values()].filter(e=>e.fromNodeId===nodeId||e.toNodeId===nodeId);
    const linkedIds=new Set(edges.flatMap(e=>[e.fromNodeId,e.toNodeId]));
    linkedIds.delete(nodeId);
    return {
      node:structuredClone(node),
      edges:edges.map(e=>structuredClone(e)),
      linkedNodes:[...linkedIds].map(id=>structuredClone(this.nodes.get(id)))
    };
  }
}

export class DigitalTwin{
  constructor({caseId,modality}){
    this.caseId=caseId;
    this.modality=modality;
    this.version=1;
    this.state={
      workflow:{status:"ACTIVE",currentStepId:"CASE_INTAKE",completionPercent:0},
      clinical:{confidence:null,findings:[]},
      cad:{revision:0,activeObjects:[],measurements:[]},
      manufacturing:{route:null,status:"NOT_RELEASED",materialLot:null,machineId:null},
      business:{turnaroundRisk:"UNKNOWN",estimatedCompletionAt:null},
      knowledge:{recommendedItems:[],competencySignals:[]}
    };
    this.timeline=[];
    this.createdAt=now();
    this.updatedAt=this.createdAt;
  }
  apply(event){
    this.version+=1;
    this.updatedAt=now();
    this.timeline.push({
      sequence:this.timeline.length+1,
      eventId:event.eventId,
      eventType:event.eventType,
      sourceModule:event.sourceModule,
      occurredAt:event.emittedAt,
      payload:structuredClone(event.payload)
    });
    switch(event.eventType){
      case "CASE_CREATED":
        this.state.workflow.currentStepId="CASE_INTAKE";
        break;
      case "SCAN_VALIDATED":
        this.state.workflow.currentStepId="DESIGN_SETUP";
        this.state.workflow.completionPercent=Math.max(this.state.workflow.completionPercent,15);
        break;
      case "DESIGN_STARTED":
        this.state.cad.revision=Math.max(1,this.state.cad.revision);
        this.state.workflow.currentStepId="AUTOMATED_DESIGN";
        this.state.workflow.completionPercent=Math.max(this.state.workflow.completionPercent,25);
        break;
      case "DESIGN_CHECKPOINT_PASSED":
        this.state.workflow.completionPercent=Math.min(80,this.state.workflow.completionPercent+8);
        break;
      case "DESIGN_CHECKPOINT_FAILED":
        this.state.workflow.status="HOLD";
        break;
      case "CLINICAL_CONFIDENCE_UPDATED":
        this.state.clinical.confidence=event.payload.confidence;
        break;
      case "COGNITIVE_FINDING_CREATED":
        this.state.clinical.findings.push(event.payload);
        break;
      case "HUMAN_QC_APPROVED":
        this.state.workflow.status="ACTIVE";
        this.state.workflow.currentStepId="PRODUCTION";
        this.state.workflow.completionPercent=Math.max(this.state.workflow.completionPercent,75);
        break;
      case "MANUFACTURING_ROUTE_RECOMMENDED":
        this.state.manufacturing.route=event.payload.route;
        break;
      case "PRODUCTION_RELEASED":
        this.state.manufacturing.status="RELEASED";
        break;
      case "FINAL_QC_PASSED":
        this.state.workflow.currentStepId="SHIP_AND_BILL";
        this.state.workflow.completionPercent=Math.max(this.state.workflow.completionPercent,92);
        break;
      case "SHIPMENT_DISPATCHED":
        this.state.workflow.currentStepId="BILLING";
        this.state.workflow.completionPercent=Math.max(this.state.workflow.completionPercent,96);
        break;
      case "CASE_COMPLETED":
        this.state.workflow.status="COMPLETE";
        this.state.workflow.currentStepId="COMPLETE";
        this.state.workflow.completionPercent=100;
        break;
      case "TURNAROUND_RISK_UPDATED":
        this.state.business.turnaroundRisk=event.payload.risk;
        this.state.business.estimatedCompletionAt=event.payload.estimatedCompletionAt??null;
        break;
      case "TRAINING_RECOMMENDED":
        this.state.knowledge.recommendedItems.push(event.payload);
        break;
      case "COMPETENCY_SIGNAL_UPDATED":
        this.state.knowledge.competencySignals.push(event.payload);
        break;
    }
    return this.snapshot();
  }
  snapshot(){
    return structuredClone({
      caseId:this.caseId,modality:this.modality,version:this.version,
      state:this.state,timeline:this.timeline,createdAt:this.createdAt,updatedAt:this.updatedAt
    });
  }
}

function validateRecommendation(record){
  for(const key of config.recommendationRequirements){
    if(!(key in record)) throw new Error(`Recommendation missing ${key}`);
  }
  if(typeof record.confidence.score!=="number"||record.confidence.score<0||record.confidence.score>1) throw new Error("Recommendation confidence must be between 0 and 1.");
  if(!["INFO","LOW","MEDIUM","HIGH","CRITICAL"].includes(record.severity)) throw new Error("Invalid recommendation severity.");
  if(!Array.isArray(record.evidence)||record.evidence.length===0) throw new Error("Recommendation evidence must be non-empty.");
  return true;
}

export class CognitiveOrchestrator{
  constructor({bus,graph}){
    this.bus=bus;
    this.graph=graph;
    this.twins=new Map();
    this.recommendations=new Map();
    this.engineConfig=new Map(config.engines.map(e=>[e.engineId,e]));
    this.bus.on("*",event=>this.handleEvent(event));
  }
  ensureTwin(caseId,modality="UNKNOWN"){
    if(!this.twins.has(caseId)) this.twins.set(caseId,new DigitalTwin({caseId,modality}));
    return this.twins.get(caseId);
  }
  registerCase({caseId,modality,doctorId=null,patientId=null}){
    const twin=this.ensureTwin(caseId,modality);
    this.graph.upsertNode({nodeId:`CASE:${caseId}`,nodeType:"CASE",label:caseId,properties:{modality}});
    if(doctorId){
      this.graph.upsertNode({nodeId:`DOCTOR:${doctorId}`,nodeType:"DOCTOR",label:doctorId});
      this.graph.connect({fromNodeId:`CASE:${caseId}`,toNodeId:`DOCTOR:${doctorId}`,edgeType:"PRESCRIBED_BY"});
    }
    if(patientId){
      this.graph.upsertNode({nodeId:`PATIENT:${patientId}`,nodeType:"PATIENT",label:patientId});
      this.graph.connect({fromNodeId:`CASE:${caseId}`,toNodeId:`PATIENT:${patientId}`,edgeType:"RELATED_TO"});
    }
    return twin.snapshot();
  }
  createRecommendation(input){
    const record={
      recommendationId:input.recommendationId??crypto.randomUUID(),
      engineId:input.engineId,
      caseId:input.caseId,
      title:input.title,
      summary:input.summary,
      evidence:structuredClone(input.evidence),
      confidence:structuredClone(input.confidence),
      assumptions:structuredClone(input.assumptions??[]),
      severity:input.severity,
      recommendedAction:input.recommendedAction,
      successCriteria:input.successCriteria,
      humanReview:structuredClone(input.humanReview),
      createdAt:now(),
      status:"OPEN"
    };
    if(!this.engineConfig.has(record.engineId)) throw new Error(`Unknown engineId: ${record.engineId}`);
    validateRecommendation(record);
    this.recommendations.set(record.recommendationId,record);
    return structuredClone(record);
  }
  handleEvent(event){
    const modality=event.payload?.modality??this.twins.get(event.caseId)?.modality??"UNKNOWN";
    const twin=this.ensureTwin(event.caseId,modality);
    twin.apply(event);
    this.graph.upsertNode({
      nodeId:`EVENT:${event.eventId}`,nodeType:"EVENT",label:event.eventType,
      properties:{caseId:event.caseId,sourceModule:event.sourceModule,emittedAt:event.emittedAt}
    });
    if(!this.graph.nodes.has(`CASE:${event.caseId}`)){
      this.graph.upsertNode({nodeId:`CASE:${event.caseId}`,nodeType:"CASE",label:event.caseId,properties:{modality}});
    }
    this.graph.connect({fromNodeId:`CASE:${event.caseId}`,toNodeId:`EVENT:${event.eventId}`,edgeType:"CAUSED_EVENT"});
    if(event.eventType==="DESIGN_CHECKPOINT_FAILED"){
      const recommendation=this.createRecommendation({
        engineId:"CAD_INTELLIGENCE",
        caseId:event.caseId,
        title:"Design checkpoint correction required",
        summary:event.payload?.summary??"The current design checkpoint did not satisfy its configured success criteria.",
        evidence:[{eventId:event.eventId,eventType:event.eventType,payload:event.payload}],
        confidence:{score:0.95,band:"HIGH"},
        assumptions:["The upstream validation result is current and belongs to this case revision."],
        severity:event.payload?.severity??"HIGH",
        recommendedAction:event.payload?.recommendedAction??"Open the failed checkpoint, review the measured deficiency, correct the design, and rerun validation.",
        successCriteria:event.payload?.successCriteria??"The checkpoint passes its configured validation rule.",
        humanReview:{required:true,role:"CAD_DESIGNER_OR_QC"}
      });
      this.bus.publish({
        eventType:"CAD_RECOMMENDATION_CREATED",
        sourceModule:"CAD_STUDIO",
        caseId:event.caseId,
        payload:recommendation,
        actorId:"CAD_INTELLIGENCE"
      });
    }
    if(event.eventType==="FINAL_QC_FAILED"){
      const recommendation=this.createRecommendation({
        engineId:"KNOWLEDGE_INTELLIGENCE",
        caseId:event.caseId,
        title:"Targeted remediation training recommended",
        summary:"A failed final QC event indicates that the responsible workflow step should be reviewed before rework.",
        evidence:[{eventId:event.eventId,eventType:event.eventType,payload:event.payload}],
        confidence:{score:0.90,band:"HIGH"},
        assumptions:["The QC failure classification accurately identifies the affected production or design step."],
        severity:"MEDIUM",
        recommendedAction:"Assign the matching SOP and guided learning path before the case re-enters production.",
        successCriteria:"The assigned staff member completes the learning step and the corrected case passes final QC.",
        humanReview:{required:true,role:"SUPERVISOR"}
      });
      this.bus.publish({
        eventType:"TRAINING_RECOMMENDED",
        sourceModule:"KNOWLEDGE_CENTER",
        caseId:event.caseId,
        payload:recommendation,
        actorId:"KNOWLEDGE_INTELLIGENCE"
      });
    }
  }
  getTwin(caseId){
    const twin=this.twins.get(caseId);
    if(!twin) throw new Error(`Unknown digital twin: ${caseId}`);
    return twin.snapshot();
  }
  getRecommendations(caseId){
    return [...this.recommendations.values()]
      .filter(r=>r.caseId===caseId)
      .sort((a,b)=>severityRank(b.severity)-severityRank(a.severity)||b.createdAt.localeCompare(a.createdAt))
      .map(r=>structuredClone(r));
  }
}
