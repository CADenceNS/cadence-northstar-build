import fs from "node:fs";
import crypto from "node:crypto";

const configuration=JSON.parse(fs.readFileSync(new URL("../config/guided-workflows.json",import.meta.url),"utf8"));

export class GuidedCompletionEngine{
  constructor({store=null}={}){
    this.config=configuration;
    this.store=store;
    this.cases=new Map();
    if(this.store){
      for(const record of this.store.listCases()) this.cases.set(record.caseId,record);
    }
  }
  persist(record){
    if(this.store) this.store.saveCase(record);
  }
  createCase({caseId,modality,createdBy="SYSTEM"}){
    if(!this.config.workflows[modality]) throw new Error(`Unsupported modality: ${modality}`);
    if(this.cases.has(caseId)) throw new Error(`Case already exists: ${caseId}`);
    const first=this.config.workflows[modality][0];
    const record={
      caseId,modality,currentStepId:first.stepId,status:"ACTIVE",
      completedSteps:[],evidenceByStep:{},createdBy,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()
    };
    this.cases.set(caseId,record);
    this.persist(record);
    return this.getGuidance(caseId);
  }
  getRecord(caseId){
    const record=this.cases.get(caseId);
    if(!record) throw new Error(`Unknown case: ${caseId}`);
    return record;
  }
  getStep(record){
    const step=this.config.workflows[record.modality].find(item=>item.stepId===record.currentStepId);
    if(!step) throw new Error(`Workflow configuration is missing step ${record.currentStepId}`);
    return step;
  }
  getGuidance(caseId){
    const record=this.getRecord(caseId);
    if(record.status==="COMPLETE"){
      return {
        caseId,modality:record.modality,status:"COMPLETE",
        nextAction:"No additional workflow action is required.",
        instruction:"The case has successfully completed the configured NorthStar workflow.",
        successCriteria:"All workflow steps have verified evidence and the case is complete.",
        completionPercent:100
      };
    }
    const step=this.getStep(record);
    const total=this.config.workflows[record.modality].length;
    return {
      caseId,
      modality:record.modality,
      status:record.status,
      currentStepId:step.stepId,
      responsibleModule:step.module,
      instruction:step.instruction,
      successCriteria:step.successCriteria,
      requiredEvidence:step.requiredEvidence,
      completionPercent:Math.round((record.completedSteps.length/total)*100),
      completedSteps:[...record.completedSteps],
      nextStepId:step.nextStepId
    };
  }
  completeStep({caseId,stepId,evidence,completedBy}){
    const record=this.getRecord(caseId);
    if(record.status!=="ACTIVE") throw new Error(`Case ${caseId} is not active.`);
    const step=this.getStep(record);
    if(step.stepId!==stepId) throw new Error(`Expected step ${step.stepId}, received ${stepId}.`);
    if(!completedBy||typeof completedBy!=="string") throw new Error("completedBy is required.");
    if(!evidence||typeof evidence!=="object"||Array.isArray(evidence)) throw new Error("evidence must be an object.");
    for(const key of step.requiredEvidence){
      if(!(key in evidence)) throw new Error(`Missing required evidence: ${key}`);
    }
    if(evidence.SYSTEM_VALIDATION!==true) throw new Error("SYSTEM_VALIDATION must be true before progression.");
    if(evidence.USER_ACKNOWLEDGEMENT!==true) throw new Error("USER_ACKNOWLEDGEMENT must be true before progression.");
    if(typeof evidence.AUDIT_EVENT!=="string"||evidence.AUDIT_EVENT.length<8) throw new Error("AUDIT_EVENT must be a stable audit identifier.");
    record.completedSteps.push(step.stepId);
    record.evidenceByStep[step.stepId]={
      evidence:structuredClone(evidence),
      completedBy,
      completedAt:new Date().toISOString(),
      completionId:crypto.randomUUID()
    };
    if(step.nextStepId==="COMPLETE"){
      record.currentStepId="COMPLETE";
      record.status="COMPLETE";
    }else{
      const exists=this.config.workflows[record.modality].some(item=>item.stepId===step.nextStepId);
      if(!exists) throw new Error(`Configured next step does not exist: ${step.nextStepId}`);
      record.currentStepId=step.nextStepId;
    }
    record.updatedAt=new Date().toISOString();
    this.persist(record);
    return this.getGuidance(caseId);
  }
  routeEvent(event){
    const record=this.cases.get(event.caseId);
    if(!record) return {handled:false,reason:"CASE_NOT_REGISTERED"};
    const map={
      CASE_CREATED:"CASE_INTAKE",
      SCAN_VALIDATED:"DESIGN_SETUP",
      AUTOMATED_DESIGN_COMPLETE:"HUMAN_QC",
      HUMAN_QC_APPROVED:"PRODUCTION",
      FINAL_QC_PASSED:"SHIP_AND_BILL",
      CASE_COMPLETED:"COMPLETE"
    };
    return {handled:true,caseId:event.caseId,currentStepId:record.currentStepId,suggestedStepId:map[event.eventType]??record.currentStepId};
  }
}
