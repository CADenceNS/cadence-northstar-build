export const MODALITIES = Object.freeze(["FIXED","IMPLANT","REMOVABLE","ORTHO","SLEEP","DIAGNOSTICS"]);

export const VARIANTS = Object.freeze({
  FIXED:["CROWN","BRIDGE","VENEER","INLAY","ONLAY"],
  IMPLANT:["CUSTOM_ABUTMENT","SCREW_RETAINED_CROWN","SURGICAL_GUIDE"],
  REMOVABLE:["FULL_DENTURE","PARTIAL_FRAMEWORK"],
  ORTHO:["CLEAR_ALIGNER","RETAINER"],
  SLEEP:["MAD","NIGHTGUARD","SPLINT"],
  DIAGNOSTICS:["AESTHETIC_MOCKUP","DIAGNOSTIC_MODEL"]
});

const BASE_RULES = Object.freeze({
  FIXED:{
    CROWN:{material:"Zirconia or prescribed restorative material",minimumThicknessMm:0.8,translucency:"Case-specific",manufacturing:"DRY_MILL_ZIRCONIA"},
    BRIDGE:{material:"Zirconia or prescribed bridge material",minimumThicknessMm:1.0,translucency:"Case-specific",manufacturing:"DRY_MILL_ZIRCONIA"},
    VENEER:{material:"Lithium Disilicate",minimumThicknessMm:0.4,translucency:"High Translucency",manufacturing:"FIVE_AXIS_WET_MILL_GLASS_CERAMIC"},
    INLAY:{material:"Lithium Disilicate",minimumThicknessMm:1.0,translucency:"Medium Translucency",manufacturing:"FIVE_AXIS_WET_MILL_GLASS_CERAMIC"},
    ONLAY:{material:"Lithium Disilicate",minimumThicknessMm:1.0,translucency:"Medium Translucency",manufacturing:"FIVE_AXIS_WET_MILL_GLASS_CERAMIC"}
  },
  IMPLANT:{
    CUSTOM_ABUTMENT:{material:"Titanium Grade 5 or prescribed zirconia hybrid",minimumThicknessMm:0.5,manufacturing:"FIVE_AXIS_TITANIUM_MILL"},
    SCREW_RETAINED_CROWN:{material:"Zirconia with validated Ti-base interface",minimumThicknessMm:0.8,manufacturing:"DRY_MILL_ZIRCONIA"},
    SURGICAL_GUIDE:{material:"Biocompatible Class I/II Printing Resin",sleeveGapOffsetMm:0.1,minimumNerveSafetyMm:2.0,manufacturing:"DLP_385NM_SURGICAL_GUIDE"}
  },
  REMOVABLE:{
    FULL_DENTURE:{material:"Validated denture base resin with denture tooth system",manufacturing:"DLP_385NM_DENTURE"},
    PARTIAL_FRAMEWORK:{materialOptions:["Co-Cr (Cobalt-Chromium)","PEEK/Pekkton thermoplastic"],allowedUndercutDepthMm:[0.25,0.50],manufacturing:"METAL_LASER_OR_FRAMEWORK_MILL"}
  },
  ORTHO:{
    CLEAR_ALIGNER:{material:"PET-G / Polyurethane dual-shell aligner film sheet",maxRotationDegPerStage:2.0,maxTranslationMmPerStage:0.25,manufacturing:"DLP_385NM_ORTHO_MODEL_THERMOFORM"},
    RETAINER:{material:"PET-G retainer sheet",manufacturing:"DLP_385NM_ORTHO_MODEL_THERMOFORM"}
  },
  SLEEP:{
    MAD:{material:"Dual-Laminate Acrylic with hard/soft layers",hardware:"Titratable Herbst/Advancement hardware",maxFunctionalVerticalOpeningMm:4.0,manufacturing:"DLP_385NM_SLEEP_APPLIANCE"},
    NIGHTGUARD:{material:"Validated hard or dual-laminate splint material",maxFunctionalVerticalOpeningMm:4.0,manufacturing:"DLP_385NM_SPLINT"},
    SPLINT:{material:"Validated hard splint resin",maxFunctionalVerticalOpeningMm:4.0,manufacturing:"DLP_385NM_SPLINT"}
  },
  DIAGNOSTICS:{
    AESTHETIC_MOCKUP:{material:"Printable temporary or mock-up resin",manufacturing:"DLP_385NM_MOCKUP"},
    DIAGNOSTIC_MODEL:{material:"Standard grey/tan high-accuracy model resin",manufacturing:"DLP_385NM_MODEL"}
  }
});

export function assertCaseEnvelope(input){
  if(!input || typeof input !== "object" || Array.isArray(input)) throw new TypeError("Case payload must be an object.");
  const required=["caseId","modality","variant","files","metrics"];
  for(const key of required) if(!(key in input)) throw new Error(`Missing required field: ${key}`);
  if(typeof input.caseId !== "string" || input.caseId.trim().length < 3) throw new Error("caseId must be a non-empty stable identifier.");
  if(!MODALITIES.includes(input.modality)) throw new Error(`Unsupported modality: ${input.modality}`);
  if(!VARIANTS[input.modality].includes(input.variant)) throw new Error(`Variant ${input.variant} is invalid for modality ${input.modality}.`);
  if(!Array.isArray(input.files) || input.files.length === 0) throw new Error("At least one scan or design file is required.");
  for(const [index,file] of input.files.entries()){
    if(!file || typeof file !== "object") throw new Error(`files[${index}] must be an object.`);
    if(typeof file.path !== "string" || !file.path.startsWith("s3://")) throw new Error(`files[${index}].path must be an s3:// URI.`);
    if(!["STL","OBJ","PLY","3OX","DICOM","PDF","PNG","JPG"].includes(file.format)) throw new Error(`files[${index}].format is unsupported.`);
    if(typeof file.sha256 !== "string" || !/^[a-f0-9]{64}$/i.test(file.sha256)) throw new Error(`files[${index}].sha256 must be a 64-character hexadecimal digest.`);
  }
  if(!input.metrics || typeof input.metrics !== "object" || Array.isArray(input.metrics)) throw new Error("metrics must be an object.");
  return true;
}

export function determinePlan(input){
  assertCaseEnvelope(input);
  const template=BASE_RULES[input.modality][input.variant];
  const plan=structuredClone(template);
  plan.modality=input.modality;
  plan.variant=input.variant;
  plan.caseId=input.caseId;
  plan.shade=input.shade ?? "NOT_PRESCRIBED";
  plan.humanApprovalRequired=true;
  plan.generatedAt=new Date().toISOString();
  if(input.prescribedMaterial){
    plan.requestedMaterial=input.prescribedMaterial;
    plan.materialOverrideRequiresHumanApproval=true;
  }
  if(input.modality==="REMOVABLE" && input.variant==="PARTIAL_FRAMEWORK"){
    const requested=input.prescribedMaterial ?? plan.materialOptions[0];
    if(!plan.materialOptions.includes(requested)) throw new Error(`Unsupported partial-framework material: ${requested}`);
    plan.material=requested;
  }
  return plan;
}
