const ROUTES=Object.freeze({
  DRY_MILL_ZIRCONIA:{target:"5-axis dry mill",queue:"CAM-ZIRCONIA",acceptedFormats:["STL","3OX"]},
  FIVE_AXIS_WET_MILL_GLASS_CERAMIC:{target:"5-axis wet mill",queue:"CAM-GLASS-CERAMIC",acceptedFormats:["STL","3OX"]},
  FIVE_AXIS_TITANIUM_MILL:{target:"5-axis metal mill",queue:"CAM-TITANIUM",acceptedFormats:["STL","3OX"]},
  DLP_385NM_SURGICAL_GUIDE:{target:"385nm UV DLP 3D printer",queue:"PRINT-SURGICAL-GUIDE",acceptedFormats:["STL","3OX"]},
  METAL_LASER_OR_FRAMEWORK_MILL:{target:"metal laser fusion or validated framework mill",queue:"CAM-PARTIAL-FRAMEWORK",acceptedFormats:["STL","3OX"]},
  DLP_385NM_DENTURE:{target:"385nm UV DLP 3D printer",queue:"PRINT-DENTURE",acceptedFormats:["STL","3OX"]},
  DLP_385NM_ORTHO_MODEL_THERMOFORM:{target:"385nm UV DLP model printer then thermoforming cell",queue:"PRINT-ORTHO",acceptedFormats:["STL","3OX"]},
  DLP_385NM_SLEEP_APPLIANCE:{target:"385nm UV DLP 3D printer",queue:"PRINT-SLEEP",acceptedFormats:["STL","3OX"]},
  DLP_385NM_SPLINT:{target:"385nm UV DLP 3D printer",queue:"PRINT-SPLINT",acceptedFormats:["STL","3OX"]},
  DLP_385NM_MOCKUP:{target:"385nm UV DLP 3D printer",queue:"PRINT-MOCKUP",acceptedFormats:["STL","3OX"]},
  DLP_385NM_MODEL:{target:"385nm UV DLP 3D printer",queue:"PRINT-MODEL",acceptedFormats:["STL","3OX"]}
});

export function buildManifest(input,plan,quality){
  if(!quality.passed) throw new Error(`Manifest blocked by failed checks: ${quality.failedCheckIds.join(", ")}`);
  const route=ROUTES[plan.manufacturing];
  if(!route) throw new Error(`No manufacturing route configured for ${plan.manufacturing}`);
  const designFiles=input.files.filter(file=>["STL","3OX"].includes(file.format));
  if(designFiles.length===0) throw new Error("At least one STL or 3OX manufacturing file is required.");
  const screenshots=input.files.filter(file=>["PNG","JPG"].includes(file.format));
  return {
    schemaVersion:"1.0.0",
    manifestId:`MFG-${input.caseId}-${Date.now()}`,
    caseId:input.caseId,
    modality:input.modality,
    variant:input.variant,
    generatedAt:new Date().toISOString(),
    humanQcRequired:true,
    designPlan:plan,
    assets:{
      manufacturingFiles:designFiles.map(file=>({path:file.path,format:file.format,sha256:file.sha256})),
      automaticAestheticScreenshots:screenshots.map(file=>({path:file.path,format:file.format,sha256:file.sha256})),
      sourceFiles:input.files.map(file=>({path:file.path,format:file.format,sha256:file.sha256}))
    },
    complianceChecklist:quality.checks.map(check=>({
      checkId:check.id,
      passed:check.passed,
      actual:check.actual,
      required:check.required,
      details:check.details
    })),
    manufacturing:{
      routeKey:plan.manufacturing,
      target:route.target,
      queue:route.queue,
      acceptedFormats:route.acceptedFormats,
      releaseState:"AWAITING_HUMAN_QC"
    },
    qcDashboard:{
      requiredActions:["REVIEW_3D_DESIGN","REVIEW_AUTOMATED_SCREENSHOTS","VERIFY_PRESCRIPTION","VERIFY_MATERIAL_AND_SHADE","APPROVE_OR_REJECT"],
      approvalOptions:["APPROVE_FOR_MANUFACTURING","RETURN_TO_AUTOMATED_DESIGN","RETURN_TO_MANUAL_DESIGN","REJECT_CASE"],
      electronicSignatureRequired:true
    }
  };
}
