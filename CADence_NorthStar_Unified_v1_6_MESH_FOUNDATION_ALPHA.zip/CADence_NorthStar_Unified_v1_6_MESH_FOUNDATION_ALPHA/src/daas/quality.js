const finite=(value,name)=>{
  if(typeof value!=="number" || !Number.isFinite(value)) throw new Error(`${name} must be a finite number.`);
  return value;
};
const boolCheck=(id,passed,actual,required,details)=>({id,passed:Boolean(passed),actual,required,details});

function fixedChecks(input,plan){
  const m=input.metrics;
  const continuity=finite(m.marginClosedLoopGapMm,"marginClosedLoopGapMm");
  const sampledWall=Array.isArray(m.wallThicknessSamplesMm)?m.wallThicknessSamplesMm:[];
  if(sampledWall.length===0) throw new Error("wallThicknessSamplesMm requires at least one measurement.");
  sampledWall.forEach((v,i)=>finite(v,`wallThicknessSamplesMm[${i}]`));
  const minWall=Math.min(...sampledWall);
  return [
    boolCheck("FIXED_MARGIN_CONTINUITY",continuity<=0.02,continuity,"<= 0.02 mm maximum closed-loop discontinuity","Margin polyline must form a continuous closed loop within tolerance."),
    boolCheck("FIXED_MINIMUM_WALL",minWall>=plan.minimumThicknessMm,minWall,`>= ${plan.minimumThicknessMm} mm`,"Minimum sampled structural cross-section must meet the modality rule.")
  ];
}
function implantChecks(input,plan){
  const m=input.metrics;
  const fixture=finite(m.minimumFixtureToRootMm,"minimumFixtureToRootMm");
  const nerve=finite(m.minimumFixtureToNerveMm,"minimumFixtureToNerveMm");
  const checks=[
    boolCheck("IMPLANT_ROOT_COLLISION",fixture>0,fixture,"> 0.00 mm","Fixture trajectory must not intersect adjacent root volumes."),
    boolCheck("IMPLANT_NERVE_SAFETY",nerve>=2.0,nerve,">= 2.00 mm","Minimum fixture-to-mandibular-nerve distance.")
  ];
  if(input.variant==="SURGICAL_GUIDE"){
    const gap=finite(m.sleeveGapOffsetMm,"sleeveGapOffsetMm");
    checks.push(boolCheck("GUIDE_SLEEVE_OFFSET",Math.abs(gap-plan.sleeveGapOffsetMm)<=0.02,gap,`${plan.sleeveGapOffsetMm} mm ± 0.02 mm`,"Sleeve gap offset must match the validated guide workflow."));
  }
  return checks;
}
function removableChecks(input){
  const m=input.metrics;
  if(input.variant==="FULL_DENTURE"){
    const base=finite(m.minimumBaseThicknessMm,"minimumBaseThicknessMm");
    return [boolCheck("DENTURE_BASE_THICKNESS",base>=2.0,base,">= 2.00 mm","Minimum base thickness rule for this configured DaaS profile.")];
  }
  const depth=finite(m.claspTipUndercutDepthMm,"claspTipUndercutDepthMm");
  const line=finite(m.selectedUndercutLineMm,"selectedUndercutLineMm");
  const allowed=[0.25,0.50];
  return [
    boolCheck("PARTIAL_UNDERCUT_LINE",allowed.includes(line),line,"0.25 mm or 0.50 mm","Selected survey line must match an approved undercut depth."),
    boolCheck("PARTIAL_CLASP_TIP",Math.abs(depth-line)<=0.05,depth,`${line} mm ± 0.05 mm`,"Clasp tip must terminate near the selected calculated undercut line.")
  ];
}
function orthoChecks(input){
  const stages=input.metrics.stages;
  if(!Array.isArray(stages)||stages.length===0) throw new Error("Ortho metrics require a non-empty stages array.");
  let maxRotation=0,maxTranslation=0;
  for(const [si,stage] of stages.entries()){
    if(!Array.isArray(stage.teeth)||stage.teeth.length===0) throw new Error(`stages[${si}].teeth must be non-empty.`);
    for(const [ti,tooth] of stage.teeth.entries()){
      maxRotation=Math.max(maxRotation,Math.abs(finite(tooth.rotationDeg,`stages[${si}].teeth[${ti}].rotationDeg`)));
      maxTranslation=Math.max(maxTranslation,Math.abs(finite(tooth.translationMm,`stages[${si}].teeth[${ti}].translationMm`)));
    }
  }
  return [
    boolCheck("ORTHO_STAGE_ROTATION",maxRotation<=2.0,maxRotation,"<= 2.00 degrees per tooth per stage","Maximum absolute rotation across all staged tooth movements."),
    boolCheck("ORTHO_STAGE_TRANSLATION",maxTranslation<=0.25,maxTranslation,"<= 0.25 mm per tooth per stage","Maximum absolute translation across all staged tooth movements.")
  ];
}
function sleepChecks(input){
  const opening=finite(input.metrics.verticalOpeningMm,"verticalOpeningMm");
  const tmjLeft=finite(input.metrics.leftTmjSpaceChangeMm,"leftTmjSpaceChangeMm");
  const tmjRight=finite(input.metrics.rightTmjSpaceChangeMm,"rightTmjSpaceChangeMm");
  return [
    boolCheck("SLEEP_VERTICAL_OPENING",opening<=4.0,opening,"<= 4.00 mm","Configured functional vertical-opening window."),
    boolCheck("SLEEP_TMJ_LEFT",Math.abs(tmjLeft)<=4.0,tmjLeft,"absolute change <= 4.00 mm","Left TMJ-space change must remain inside the configured functional window."),
    boolCheck("SLEEP_TMJ_RIGHT",Math.abs(tmjRight)<=4.0,tmjRight,"absolute change <= 4.00 mm","Right TMJ-space change must remain inside the configured functional window.")
  ];
}
function diagnosticsChecks(input){
  const m=input.metrics;
  const minX=finite(m.biologicalEnvelopeMinXMm,"biologicalEnvelopeMinXMm");
  const maxX=finite(m.biologicalEnvelopeMaxXMm,"biologicalEnvelopeMaxXMm");
  const minZ=finite(m.biologicalEnvelopeMinZMm,"biologicalEnvelopeMinZMm");
  const maxZ=finite(m.biologicalEnvelopeMaxZMm,"biologicalEnvelopeMaxZMm");
  const designMinX=finite(m.designMinXMm,"designMinXMm");
  const designMaxX=finite(m.designMaxXMm,"designMaxXMm");
  const designMinZ=finite(m.designMinZMm,"designMinZMm");
  const designMaxZ=finite(m.designMaxZMm,"designMaxZMm");
  const midline=finite(m.facialMidlineXMm,"facialMidlineXMm");
  const midlineCrossing=designMinX<midline && designMaxX>midline && Boolean(m.midlineCrossingProhibited);
  return [
    boolCheck("DIAGNOSTIC_BIOLOGICAL_ENVELOPE",designMinX>=minX&&designMaxX<=maxX&&designMinZ>=minZ&&designMaxZ<=maxZ,
      {designMinX,designMaxX,designMinZ,designMaxZ},{minX,maxX,minZ,maxZ},"Wax-up bounds must remain within the supplied patient biological envelope."),
    boolCheck("DIAGNOSTIC_MIDLINE",!midlineCrossing,{designMinX,designMaxX,midline},"must not cross prohibited facial midline","Midline restriction is evaluated only when the prescription prohibits crossing."),
    boolCheck("DIAGNOSTIC_INCISAL_EDGE",designMinZ>=minZ&&designMaxZ<=maxZ,{designMinZ,designMaxZ},{minZ,maxZ},"Incisal design bounds must remain inside the prescribed vertical constraints.")
  ];
}

export function evaluateQuality(input,plan){
  let checks;
  switch(input.modality){
    case "FIXED": checks=fixedChecks(input,plan); break;
    case "IMPLANT": checks=implantChecks(input,plan); break;
    case "REMOVABLE": checks=removableChecks(input,plan); break;
    case "ORTHO": checks=orthoChecks(input,plan); break;
    case "SLEEP": checks=sleepChecks(input,plan); break;
    case "DIAGNOSTICS": checks=diagnosticsChecks(input,plan); break;
    default: throw new Error(`Unsupported modality: ${input.modality}`);
  }
  const failed=checks.filter(check=>!check.passed);
  return {
    passed:failed.length===0,
    modality:input.modality,
    variant:input.variant,
    checks,
    failedCheckIds:failed.map(check=>check.id),
    evaluatedAt:new Date().toISOString(),
    disposition:failed.length===0?"SEND_TO_HUMAN_QC":"HOLD_FOR_TECHNICIAN_CORRECTION"
  };
}
