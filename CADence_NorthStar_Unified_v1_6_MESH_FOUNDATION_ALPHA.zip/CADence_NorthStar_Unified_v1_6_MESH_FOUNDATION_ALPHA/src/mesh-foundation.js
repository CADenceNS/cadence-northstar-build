import fs from "node:fs";
import crypto from "node:crypto";

const clone=v=>structuredClone(v);
const now=()=>new Date().toISOString();
const EPS=1e-12;

function vkey(v){return `${v[0].toFixed(8)}|${v[1].toFixed(8)}|${v[2].toFixed(8)}`;}
function ekey(a,b){const ka=vkey(a),kb=vkey(b);return ka<kb?`${ka}::${kb}`:`${kb}::${ka}`;}
function sub(a,b){return [a[0]-b[0],a[1]-b[1],a[2]-b[2]];}
function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}
function dot(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
function norm(v){return Math.sqrt(dot(v,v));}
function normalize(v){const n=norm(v);return n<EPS?[0,0,0]:[v[0]/n,v[1]/n,v[2]/n];}
function triangleArea(a,b,c){return 0.5*norm(cross(sub(b,a),sub(c,a)));}
function geometricNormal(a,b,c){return normalize(cross(sub(b,a),sub(c,a)));}

export class StlParser{
  static parseFile(filePath){
    const buffer=fs.readFileSync(filePath);
    return this.parseBuffer(buffer,{sourceName:filePath});
  }
  static parseBuffer(buffer,{sourceName="memory"}={}){
    if(!Buffer.isBuffer(buffer)) buffer=Buffer.from(buffer);
    const asciiCandidate=buffer.subarray(0,Math.min(buffer.length,512)).toString("utf8").trimStart().startsWith("solid");
    if(asciiCandidate){
      try{
        const ascii=this.parseAscii(buffer.toString("utf8"),sourceName);
        if(ascii.triangles.length>0) return ascii;
      }catch{}
    }
    return this.parseBinary(buffer,sourceName);
  }
  static parseAscii(text,sourceName){
    const lines=text.split(/\r?\n/);
    const triangles=[];let declaredNormal=[0,0,0];let vertices=[];
    for(const raw of lines){
      const line=raw.trim();
      if(line.startsWith("facet normal")){
        const p=line.split(/\s+/).slice(2).map(Number);
        declaredNormal=[p[0]??0,p[1]??0,p[2]??0];
      }else if(line.startsWith("vertex")){
        const p=line.split(/\s+/).slice(1).map(Number);
        if(p.length!==3||p.some(x=>!Number.isFinite(x))) throw new Error("Invalid ASCII STL vertex.");
        vertices.push(p);
      }else if(line==="endfacet"){
        if(vertices.length!==3) throw new Error("ASCII STL facet does not contain exactly three vertices.");
        triangles.push({normal:declaredNormal,vertices:vertices.map(v=>[...v])});
        vertices=[];
      }
    }
    return {format:"STL_ASCII",sourceName,triangles};
  }
  static parseBinary(buffer,sourceName){
    if(buffer.length<84) throw new Error("Binary STL is too short.");
    const count=buffer.readUInt32LE(80);
    const expected=84+count*50;
    if(buffer.length<expected) throw new Error("Binary STL length does not match triangle count.");
    const triangles=[];
    let offset=84;
    for(let i=0;i<count;i++){
      const normal=[buffer.readFloatLE(offset),buffer.readFloatLE(offset+4),buffer.readFloatLE(offset+8)];
      offset+=12;
      const vertices=[];
      for(let j=0;j<3;j++){
        vertices.push([buffer.readFloatLE(offset),buffer.readFloatLE(offset+4),buffer.readFloatLE(offset+8)]);
        offset+=12;
      }
      offset+=2;
      triangles.push({normal,vertices});
    }
    return {format:"STL_BINARY",sourceName,triangles};
  }
}

export class MeshAnalyzer{
  static analyze(mesh){
    const triangles=mesh.triangles??[];
    const vertexMap=new Map(), edgeMap=new Map(), adjacency=new Map();
    let area=0,degenerate=0,normalAgreements=0,normalComparable=0;
    const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];

    triangles.forEach((tri,index)=>{
      const [a,b,c]=tri.vertices;
      for(const v of [a,b,c]){
        const key=vkey(v);if(!vertexMap.has(key))vertexMap.set(key,v);
        for(let k=0;k<3;k++){if(v[k]<min[k])min[k]=v[k];if(v[k]>max[k])max[k]=v[k];}
      }
      const triArea=triangleArea(a,b,c); area+=triArea;
      if(triArea<EPS) degenerate++;
      const g=geometricNormal(a,b,c),d=normalize(tri.normal??[0,0,0]);
      if(norm(d)>EPS&&norm(g)>EPS){normalComparable++;if(dot(g,d)>=0.5)normalAgreements++;}
      for(const [u,v] of [[a,b],[b,c],[c,a]]){
        const key=ekey(u,v);
        if(!edgeMap.has(key)) edgeMap.set(key,[]);
        edgeMap.get(key).push(index);
      }
      adjacency.set(index,new Set());
    });

    for(const owners of edgeMap.values()){
      if(owners.length===2){
        adjacency.get(owners[0]).add(owners[1]);adjacency.get(owners[1]).add(owners[0]);
      }else if(owners.length>2){
        for(const a of owners) for(const b of owners) if(a!==b) adjacency.get(a).add(b);
      }
    }

    let components=0;const visited=new Set();
    for(let i=0;i<triangles.length;i++){
      if(visited.has(i))continue;components++;
      const q=[i];visited.add(i);
      while(q.length){
        const x=q.shift();
        for(const n of adjacency.get(x)??[]){if(!visited.has(n)){visited.add(n);q.push(n);}}
      }
    }

    const boundaryEdges=[...edgeMap.values()].filter(v=>v.length===1).length;
    const nonManifoldEdges=[...edgeMap.values()].filter(v=>v.length>2).length;
    const normalAgreementRatio=normalComparable?normalAgreements/normalComparable:null;
    return {
      analysisId:crypto.randomUUID(),
      format:mesh.format,
      sourceName:mesh.sourceName,
      vertexCount:vertexMap.size,
      triangleCount:triangles.length,
      boundingBox:triangles.length?{min,max,size:[max[0]-min[0],max[1]-min[1],max[2]-min[2]]}:null,
      approximateSurfaceArea:area,
      connectedComponents:components,
      edgeCount:edgeMap.size,
      boundaryEdges,
      nonManifoldEdges,
      degenerateTriangles:degenerate,
      normalAgreementRatio,
      watertightEstimate:triangles.length>0&&boundaryEdges===0&&nonManifoldEdges===0,
      analyzedAt:now()
    };
  }
}

export class MeshQualityEngine{
  constructor(config){this.thresholds=clone(config.qualityThresholds);}
  evaluate({caseId,subjectId,analysis}){
    const triangleCount=Math.max(analysis.triangleCount,1);
    const edgeCount=Math.max(analysis.edgeCount,1);
    const checks=[
      {
        findingCode:"MESH.DEGENERATE_TRIANGLES",
        title:"Degenerate triangle review",
        measuredValue:analysis.degenerateTriangles/triangleCount,
        requiredValue:this.thresholds.maxDegenerateTriangleRatio,
        unit:"ratio",
        passed:(analysis.degenerateTriangles/triangleCount)<=this.thresholds.maxDegenerateTriangleRatio,
        summary:`${analysis.degenerateTriangles} degenerate triangles were detected across ${analysis.triangleCount} triangles.`,
        recommendedAction:"Repair or remove zero-area and near-zero-area facets before downstream geometry processing."
      },
      {
        findingCode:"MESH.BOUNDARY_EDGES",
        title:"Boundary edge review",
        measuredValue:analysis.boundaryEdges/edgeCount,
        requiredValue:this.thresholds.maxBoundaryEdgeRatioClosedMesh,
        unit:"ratio",
        passed:(analysis.boundaryEdges/edgeCount)<=this.thresholds.maxBoundaryEdgeRatioClosedMesh,
        summary:`${analysis.boundaryEdges} boundary edges were detected across ${analysis.edgeCount} unique edges.`,
        recommendedAction:"Confirm whether an open surface is intentional; otherwise repair holes or incomplete scan regions."
      },
      {
        findingCode:"MESH.NON_MANIFOLD_EDGES",
        title:"Non-manifold edge review",
        measuredValue:analysis.nonManifoldEdges/edgeCount,
        requiredValue:this.thresholds.maxNonManifoldEdgeRatio,
        unit:"ratio",
        passed:(analysis.nonManifoldEdges/edgeCount)<=this.thresholds.maxNonManifoldEdgeRatio,
        summary:`${analysis.nonManifoldEdges} non-manifold edges were detected.`,
        recommendedAction:"Repair shared-edge topology before boolean, offset, or manufacturing operations."
      }
    ];
    if(analysis.normalAgreementRatio!==null){
      checks.push({
        findingCode:"MESH.NORMAL_AGREEMENT",
        title:"Facet normal orientation agreement",
        measuredValue:analysis.normalAgreementRatio,
        requiredValue:this.thresholds.minNormalAgreementRatio,
        unit:"ratio",
        passed:analysis.normalAgreementRatio>=this.thresholds.minNormalAgreementRatio,
        summary:`Declared facet normals agree with geometric normals at a ratio of ${analysis.normalAgreementRatio.toFixed(4)}.`,
        recommendedAction:"Recalculate or consistently orient facet normals before downstream processing."
      });
    }
    return checks.map(c=>({
      engineId:"MESH_QUALITY_ENGINE",caseId,subjectId,
      findingCode:c.findingCode,title:c.title,status:c.passed?"PASS":"REVIEW",
      severity:c.passed?"INFO":"HIGH",confidence:0.99,summary:c.summary,
      measuredValue:c.measuredValue,requiredValue:c.requiredValue,unit:c.unit,
      method:"DETERMINISTIC_STL_TOPOLOGY_ANALYSIS",
      recommendedAction:c.passed?"No corrective action is required for this check.":c.recommendedAction,
      successCriteria:"The deterministic mesh check satisfies the configured threshold.",
      humanReviewRequired:!c.passed
    }));
  }
}

export class MeshRepository{
  constructor(){this.records=new Map();}
  save({caseId,subjectId,fileName,format,analysis,evidenceIds=[]}){
    const record={
      meshRecordId:crypto.randomUUID(),caseId,subjectId,fileName,format,
      analysis:clone(analysis),evidenceIds:[...evidenceIds],createdAt:now()
    };
    this.records.set(record.meshRecordId,record);return clone(record);
  }
  list(caseId){return [...this.records.values()].filter(r=>r.caseId===caseId).map(clone);}
  get(meshRecordId){const v=this.records.get(meshRecordId);return v?clone(v):null;}
}
