import {EventEmitter} from "node:events";
import crypto from "node:crypto";

export class NorthStarEventBus extends EventEmitter{
  constructor({allowedEvents,allowedModules}){
    super();
    this.allowedEvents=new Set(allowedEvents);
    this.allowedModules=new Set(allowedModules);
    this.history=[];
    this.setMaxListeners(100);
  }
  publish({eventType,sourceModule,caseId,payload={},actorId="SYSTEM"}){
    if(!this.allowedEvents.has(eventType)) throw new Error(`Unsupported eventType: ${eventType}`);
    if(!this.allowedModules.has(sourceModule)) throw new Error(`Unsupported sourceModule: ${sourceModule}`);
    if(typeof caseId!=="string"||caseId.trim().length<3) throw new Error("caseId must contain at least 3 characters.");
    const event={
      eventId:crypto.randomUUID(),
      eventType,
      sourceModule,
      caseId,
      payload:structuredClone(payload),
      actorId,
      emittedAt:new Date().toISOString()
    };
    this.history.push(event);
    if(this.history.length>10000) this.history.shift();
    this.emit(eventType,event);
    this.emit("*",event);
    return event;
  }
  getHistory(caseId){
    return this.history.filter(event=>event.caseId===caseId).map(event=>structuredClone(event));
  }
}
