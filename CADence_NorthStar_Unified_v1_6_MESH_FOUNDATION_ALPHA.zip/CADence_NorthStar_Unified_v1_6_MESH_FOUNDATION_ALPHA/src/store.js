import fs from "node:fs";
import path from "node:path";

export class DurableJsonStore{
  constructor(filePath){
    this.filePath=path.resolve(filePath);
    fs.mkdirSync(path.dirname(this.filePath),{recursive:true});
    if(!fs.existsSync(this.filePath)) this.write({cases:{},events:[],deliveries:[]});
    this.state=this.read();
  }
  read(){
    const raw=fs.readFileSync(this.filePath,"utf8");
    const parsed=JSON.parse(raw);
    if(!parsed.cases||typeof parsed.cases!=="object") throw new Error("Store is missing cases.");
    if(!Array.isArray(parsed.events)) throw new Error("Store is missing events.");
    if(!Array.isArray(parsed.deliveries)) throw new Error("Store is missing deliveries.");
    return parsed;
  }
  write(next){
    const temp=`${this.filePath}.tmp`;
    fs.writeFileSync(temp,JSON.stringify(next,null,2),"utf8");
    fs.renameSync(temp,this.filePath);
  }
  transact(mutator){
    const draft=structuredClone(this.state);
    const result=mutator(draft);
    this.write(draft);
    this.state=draft;
    return result;
  }
  getCase(caseId){return this.state.cases[caseId]?structuredClone(this.state.cases[caseId]):null;}
  listCases(){return Object.values(this.state.cases).map(item=>structuredClone(item));}
  saveCase(record){
    return this.transact(state=>{
      state.cases[record.caseId]=structuredClone(record);
      return structuredClone(record);
    });
  }
  appendEvent(event){
    return this.transact(state=>{
      state.events.push(structuredClone(event));
      if(state.events.length>50000) state.events.splice(0,state.events.length-50000);
      return structuredClone(event);
    });
  }
  appendDelivery(delivery){
    return this.transact(state=>{
      state.deliveries.push(structuredClone(delivery));
      if(state.deliveries.length>50000) state.deliveries.splice(0,state.deliveries.length-50000);
      return structuredClone(delivery);
    });
  }
  getEvents(caseId){return this.state.events.filter(e=>e.caseId===caseId).map(e=>structuredClone(e));}
  getDeliveries(caseId){return this.state.deliveries.filter(d=>d.caseId===caseId).map(d=>structuredClone(d));}
}
