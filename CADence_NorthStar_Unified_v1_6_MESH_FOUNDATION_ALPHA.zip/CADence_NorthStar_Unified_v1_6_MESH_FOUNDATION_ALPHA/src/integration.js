export function wireNorthStarModules(bus,engine){
  const deliveries=[];
  bus.on("*",event=>{
    const guidance=engine.routeEvent(event);
    deliveries.push({
      deliveryId:event.eventId,
      caseId:event.caseId,
      eventType:event.eventType,
      sourceModule:event.sourceModule,
      deliveredTo:["COMMAND_CENTER","AUDIT","KNOWLEDGE_CENTER"],
      guidance,
      deliveredAt:new Date().toISOString()
    });
  });
  const downstream={
    CASE_CREATED:["DIGITAL_INTAKE","COMMAND_CENTER","AUDIT"],
    FILES_UPLOADED:["DIGITAL_INTAKE","CASES","AUDIT"],
    SCAN_VALIDATED:["CAD_STUDIO","DAAS","KNOWLEDGE_CENTER","AUDIT"],
    AUTOMATED_DESIGN_COMPLETE:["QUALITY_CONTROL","PRODUCTION","AUDIT"],
    HUMAN_QC_APPROVED:["PRODUCTION","INVENTORY","BILLING","AUDIT"],
    PRODUCTION_RELEASED:["PRODUCTION","INVENTORY","COMMAND_CENTER","AUDIT"],
    FINAL_QC_PASSED:["SHIPPING","BILLING","ANALYTICS","AUDIT"],
    SHIPMENT_CREATED:["BILLING","CASES","COMMAND_CENTER","AUDIT"],
    INVOICE_CREATED:["BILLING","ANALYTICS","CASES","AUDIT"],
    CASE_COMPLETED:["ANALYTICS","CRM","CASES","COMMAND_CENTER","AUDIT"]
  };
  for(const [eventType,targets] of Object.entries(downstream)){
    bus.on(eventType,event=>{
      deliveries.push({
        deliveryId:`${event.eventId}:${eventType}`,
        caseId:event.caseId,
        eventType,
        sourceModule:event.sourceModule,
        deliveredTo:targets,
        guidance:engine.routeEvent(event),
        deliveredAt:new Date().toISOString()
      });
    });
  }
  return {
    getDeliveries(caseId){return deliveries.filter(item=>item.caseId===caseId).map(item=>structuredClone(item));}
  };
}
