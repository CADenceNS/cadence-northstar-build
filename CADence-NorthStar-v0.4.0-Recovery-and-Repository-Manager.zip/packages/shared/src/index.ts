export type DepartmentStatus = 'healthy' | 'attention' | 'blocked';
export type RecordStatus = 'active' | 'inactive' | 'prospect';
export type CaseStatus = 'received' | 'in-production' | 'qc' | 'ready-to-ship' | 'completed';
export type ProductionRoute = 'A' | 'B' | 'C';

export interface DepartmentSnapshot { name: string; activeCases: number; status: DepartmentStatus; }
export interface DashboardSnapshot {
  generatedAt: string; casesReceivedToday: number; casesDueToday: number; casesAtRisk: number;
  casesInQc: number; shipmentsReady: number; monthRevenue: number; departments: DepartmentSnapshot[];
}
export interface PracticeAccount { id: string; accountNumber: string; practiceName: string; officeManager: string; email: string; phone: string; status: RecordStatus; createdAt: string; }
export interface DoctorAccount { id: string; accountNumber: string; doctorName: string; practiceId: string; practiceName: string; email: string; phone: string; status: RecordStatus; createdAt: string; }
export interface LaboratoryCase { id: string; caseNumber: string; doctorId: string; doctorName: string; practiceName: string; patientReference: string; department: string; restorationType: string; route: ProductionRoute; receivedDate: string; dueDate: string; status: CaseStatus; notes: string; createdAt: string; }
export interface AuditEvent { id: string; at: string; actor: string; action: string; entity: string; detail: string; }
export interface RepositoryStatus { available: boolean; initialized: boolean; root: string; branch: string; remote: string; ahead: number; behind: number; clean: boolean; changes: Array<{ code: string; path: string }>; lastCommit: string; error?: string; }
export interface CommandResult { ok: boolean; message: string; output?: string; commitSha?: string; archivePath?: string; }
