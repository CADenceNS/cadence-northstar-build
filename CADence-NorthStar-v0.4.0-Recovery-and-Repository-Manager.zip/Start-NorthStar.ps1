$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js 20+ is required.' }
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) { npm install -g pnpm@9.15.0 }
pnpm install
pnpm dev
