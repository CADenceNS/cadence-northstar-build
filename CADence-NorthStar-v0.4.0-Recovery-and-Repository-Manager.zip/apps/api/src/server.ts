import cors from 'cors';
import express from 'express';
import { execFile } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { promisify } from 'node:util';
import type { CommandResult, DashboardSnapshot, RepositoryStatus } from '@northstar/shared';

const execFileAsync = promisify(execFile);
const app = express();
const port = Number(process.env.PORT ?? 4000);
const projectRoot = path.resolve(process.env.NORTHSTAR_REPOSITORY_ROOT ?? process.cwd(), process.env.NORTHSTAR_REPOSITORY_ROOT ? '' : '../..');

app.use(cors());
app.use(express.json({ limit: '1mb' }));

async function git(args: string[]): Promise<string> {
  const { stdout, stderr } = await execFileAsync('git', args, { cwd: projectRoot, timeout: 30_000, windowsHide: true });
  return `${stdout}${stderr}`.trim();
}

function safeCommitMessage(value: unknown): string {
  if (typeof value !== 'string') throw new Error('Commit message is required.');
  const message = value.trim();
  if (message.length < 3 || message.length > 120 || /[\r\n]/.test(message)) throw new Error('Commit message must be 3–120 characters on one line.');
  return message;
}

async function repositoryStatus(): Promise<RepositoryStatus> {
  try {
    await git(['--version']);
    try { await git(['rev-parse', '--is-inside-work-tree']); } catch {
      return { available: true, initialized: false, root: projectRoot, branch: 'Not initialized', remote: '', ahead: 0, behind: 0, clean: true, changes: [], lastCommit: 'No commits' };
    }
    const branch = (await git(['branch', '--show-current'])) || 'detached';
    const remote = await git(['remote', 'get-url', 'origin']).catch(() => '');
    const porcelain = await git(['status', '--porcelain=v1']);
    const changes = porcelain ? porcelain.split('\n').map((line) => ({ code: line.slice(0, 2), path: line.slice(3) })) : [];
    const lastCommit = await git(['log', '-1', '--pretty=format:%h %s']).catch(() => 'No commits');
    let ahead = 0; let behind = 0;
    if (remote && branch !== 'detached') {
      const counts = await git(['rev-list', '--left-right', '--count', `origin/${branch}...HEAD`]).catch(() => '0\t0');
      const [behindValue, aheadValue] = counts.split(/\s+/).map(Number);
      behind = Number.isFinite(behindValue) ? behindValue : 0;
      ahead = Number.isFinite(aheadValue) ? aheadValue : 0;
    }
    return { available: true, initialized: true, root: projectRoot, branch, remote, ahead, behind, clean: changes.length === 0, changes, lastCommit };
  } catch (error) {
    return { available: false, initialized: false, root: projectRoot, branch: '', remote: '', ahead: 0, behind: 0, clean: true, changes: [], lastCommit: '', error: error instanceof Error ? error.message : 'Git is unavailable.' };
  }
}

app.get('/health', (_req, res) => res.json({ service: 'cadence-northstar-api', status: 'ok', version: '0.4.0' }));
app.get('/api/dashboard', (_req, res) => {
  const snapshot: DashboardSnapshot = {
    generatedAt: new Date().toISOString(), casesReceivedToday: 18, casesDueToday: 12, casesAtRisk: 3, casesInQc: 7, shipmentsReady: 5, monthRevenue: 84250,
    departments: [
      { name: 'Receiving', activeCases: 8, status: 'healthy' }, { name: 'Model', activeCases: 11, status: 'healthy' },
      { name: 'CAD', activeCases: 19, status: 'attention' }, { name: 'Mill / Print', activeCases: 13, status: 'healthy' },
      { name: 'Ceramics', activeCases: 17, status: 'attention' }, { name: 'QC', activeCases: 7, status: 'healthy' },
      { name: 'Shipping', activeCases: 5, status: 'healthy' }
    ]
  };
  res.json(snapshot);
});
app.get('/api/repository/status', async (_req, res) => res.json(await repositoryStatus()));
app.post('/api/repository/initialize', async (_req, res) => {
  try {
    await git(['init']); await git(['branch', '-M', 'main']);
    res.json({ ok: true, message: 'Repository initialized on main.' } satisfies CommandResult);
  } catch (error) { res.status(400).json({ ok: false, message: error instanceof Error ? error.message : 'Initialization failed.' } satisfies CommandResult); }
});
app.post('/api/repository/stage', async (_req, res) => {
  try { await git(['add', '--all']); res.json({ ok: true, message: 'All changes staged.' } satisfies CommandResult); }
  catch (error) { res.status(400).json({ ok: false, message: error instanceof Error ? error.message : 'Stage failed.' } satisfies CommandResult); }
});
app.post('/api/repository/commit', async (req, res) => {
  try {
    const message = safeCommitMessage(req.body?.message); await git(['commit', '-m', message]);
    const commitSha = await git(['rev-parse', '--short', 'HEAD']);
    res.json({ ok: true, message: 'Commit created.', commitSha } satisfies CommandResult);
  } catch (error) { res.status(400).json({ ok: false, message: error instanceof Error ? error.message : 'Commit failed.' } satisfies CommandResult); }
});
app.post('/api/repository/fetch', async (_req, res) => {
  try { const output = await git(['fetch', '--prune']); res.json({ ok: true, message: 'Remote information refreshed.', output } satisfies CommandResult); }
  catch (error) { res.status(400).json({ ok: false, message: error instanceof Error ? error.message : 'Fetch failed.' } satisfies CommandResult); }
});
app.post('/api/repository/pull', async (_req, res) => {
  try { const output = await git(['pull', '--ff-only']); res.json({ ok: true, message: 'Repository updated with a fast-forward pull.', output } satisfies CommandResult); }
  catch (error) { res.status(400).json({ ok: false, message: error instanceof Error ? error.message : 'Pull blocked.' } satisfies CommandResult); }
});
app.post('/api/repository/push', async (_req, res) => {
  try { const output = await git(['push', '-u', 'origin', 'HEAD']); res.json({ ok: true, message: 'Changes pushed to GitHub.', output } satisfies CommandResult); }
  catch (error) { res.status(400).json({ ok: false, message: error instanceof Error ? error.message : 'Push failed. Verify GitHub authentication and remote settings.' } satisfies CommandResult); }
});
app.post('/api/repository/remote', async (req, res) => {
  try {
    const url = typeof req.body?.url === 'string' ? req.body.url.trim() : '';
    if (!/^https:\/\/github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+(?:\.git)?$/.test(url)) throw new Error('Enter a valid HTTPS GitHub repository URL.');
    const existing = await git(['remote']).catch(() => '');
    if (existing.split('\n').includes('origin')) await git(['remote', 'set-url', 'origin', url]); else await git(['remote', 'add', 'origin', url]);
    res.json({ ok: true, message: 'GitHub remote saved.' } satisfies CommandResult);
  } catch (error) { res.status(400).json({ ok: false, message: error instanceof Error ? error.message : 'Remote update failed.' } satisfies CommandResult); }
});
app.post('/api/repository/backup', async (_req, res) => {
  try {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-'); const backupDir = path.join(projectRoot, 'backups');
    await mkdir(backupDir, { recursive: true }); const archivePath = path.join(backupDir, `northstar-${stamp}.zip`);
    const script = `Compress-Archive -Path '${projectRoot.replace(/'/g, "''")}\\*' -DestinationPath '${archivePath.replace(/'/g, "''")}' -Force`;
    if (process.platform === 'win32') await execFileAsync('powershell.exe', ['-NoProfile', '-Command', script], { timeout: 120_000 });
    else await execFileAsync('zip', ['-qr', archivePath, '.', '-x', 'node_modules/*', '.git/*', 'backups/*', 'dist/*'], { cwd: projectRoot, timeout: 120_000 });
    await writeFile(path.join(backupDir, `northstar-${stamp}.json`), JSON.stringify({ createdAt: new Date().toISOString(), version: '0.4.0', root: projectRoot }, null, 2));
    res.json({ ok: true, message: 'Recovery backup created.', archivePath } satisfies CommandResult);
  } catch (error) { res.status(400).json({ ok: false, message: error instanceof Error ? error.message : 'Backup failed.' } satisfies CommandResult); }
});

app.listen(port, () => console.log(`CADence NorthStar API listening on http://localhost:${port}`));
