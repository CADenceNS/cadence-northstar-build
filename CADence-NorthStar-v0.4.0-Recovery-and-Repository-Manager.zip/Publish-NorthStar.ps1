param([string]$Message = 'chore: publish NorthStar update')
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
git add --all
git commit -m $Message
git push -u origin HEAD
Write-Host 'NorthStar published successfully.' -ForegroundColor Green
