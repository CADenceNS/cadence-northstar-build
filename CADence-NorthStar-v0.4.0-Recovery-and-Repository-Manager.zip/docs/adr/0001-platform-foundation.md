# ADR-0001: Platform Foundation and Multi-Tenant Architecture

- Status: Accepted
- Date: 2026-07-25

## Decision

NorthStar will use a TypeScript monorepo with separate web, API, shared-contract, database, and documentation layers. Production persistence will use PostgreSQL with explicit organization and location scoping. Browser localStorage is retained only for the v0.4.0 recovery milestone.

Repository operations are exposed through a local server-side allowlist rather than arbitrary shell execution. The user interface may request status, initialize, remote configuration, fetch, fast-forward pull, stage, commit, push, and backup operations. Git credentials remain outside NorthStar and are managed by Git or GitHub CLI.

## Consequences

- The v0.1.0 repository remains the verified recovery baseline.
- v0.4.0 restores operational features while preserving a clear migration path to production persistence.
- Destructive Git operations such as force push, hard reset, and branch deletion are intentionally excluded.
