# Changelog

## 0.4.0 — Recovery Build & Developer Command Center

- Rebuilt forward from the verified v0.1.0 repository baseline.
- Added persistent Practice CRM, Doctor CRM, and Case Control.
- Added automatic account and case numbering.
- Added Route A/B/C case routing and business-day due-date calculation.
- Added workflow progression, overdue identification, search, audit history, and JSON recovery export/import.
- Added the Developer Command Center with repository status, initialize, remote setup, fetch, safe pull, stage, commit, push, and recovery backup controls.
- Restricted repository operations to an allowlisted server-side Git command set.
- Updated application and API versioning to v0.4.0.

## 0.1.0 — Foundation

- pnpm monorepo, React web application, Express API, shared TypeScript contracts, dashboard foundation, and CI workflow.
