# CADence NorthStar

CADence NorthStar is the operating platform for Keramos Dental Laboratory.

## Current milestone

**v0.4.0 — Recovery Build & Developer Command Center**

This release was rebuilt from the verified v0.1.0 repository baseline. It includes Practice CRM, Doctor CRM, Case Control, workflow progression, audit history, JSON recovery, and a built-in repository manager.

## Local setup

Requirements: Node.js 20+, pnpm 9+, and Git.

```bash
pnpm install
pnpm dev
```

- Web: `http://localhost:5173`
- API: `http://localhost:4000`
- Health: `http://localhost:4000/health`

## Repository management

Open **Developer Command Center** inside NorthStar. Repository commands run through the local API against the NorthStar project directory. Configure the GitHub remote, stage, commit, and push from the interface. GitHub authentication remains securely managed by Git/GitHub CLI on the workstation.

For a custom repository path, set `NORTHSTAR_REPOSITORY_ROOT` before starting the API.

## Data safety

Application records use browser localStorage for this recovery milestone. Settings provides JSON export/import. The Developer Command Center creates source recovery ZIPs under `backups/`.

## Security

Never commit patient names, protected health information, passwords, tokens, API keys, or production credentials. Replace localStorage and development authentication with server-side production persistence before clinical deployment.
